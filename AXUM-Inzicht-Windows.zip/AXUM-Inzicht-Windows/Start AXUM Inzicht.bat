@echo off
title AXUM Inzicht
cd /d "%~dp0"

rem ---- instellingen ----
rem IP-adres van de AXUM-engine
set AXUM_ENGINE=192.168.1.222

set AXUM_DB_HOST=%AXUM_ENGINE%
set AXUM_DB_PORT=5432
set AXUM_WEB_URL=http://%AXUM_ENGINE%
set PYTHONIOENCODING=utf-8

echo.
echo  AXUM Inzicht
echo  ------------
echo  Engine:  %AXUM_ENGINE%
echo  Pagina:  http://localhost:8080
echo.
echo  Laat dit venster open zolang je de pagina gebruikt.
echo  Sluit dit venster om AXUM Inzicht te stoppen.
echo.

if not exist "python\python.exe" (
  echo  FOUT: python\python.exe niet gevonden.
  echo  Pak het zip-bestand eerst helemaal uit ^(rechtsklik - Alles uitpakken^)
  echo  en start dit bestand vanuit de uitgepakte map.
  pause
  exit /b 1
)
python\python.exe -c "import psycopg2, uvicorn, fastapi" || (
  echo.
  echo  FOUT: een onderdeel kon niet geladen worden ^(zie melding hierboven^).
  echo  Controleer of de virusscanner bestanden uit de map "python" heeft verwijderd.
  pause
  exit /b 1
)

rem browser na 3 seconden openen (dan is de server klaar)
start "" /b cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:8080"

python\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8080 --timeout-graceful-shutdown 2 --log-level warning

echo.
echo  AXUM Inzicht is gestopt.
pause
