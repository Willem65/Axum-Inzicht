// AXUM Inzicht - frontend (alleen lezen)
let S = null;            // laatste state van /api/state
let consoleSel = 1;
const $ = (id) => document.getElementById(id);
const esc = (v) => String(v ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const hex = (n) => n.toString(16).toUpperCase().padStart(8, "0");
const db = (v) => (v <= -140 ? "-∞" : (v > 0 ? "+" : "") + v.toFixed(1)) + " dB";

// ---------- tabs ----------
document.querySelectorAll("#tabs button").forEach((b) =>
  b.addEventListener("click", () => {
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("active", x === b));
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + b.dataset.view));
    if (b.dataset.view === "flow") requestAnimationFrame(drawFlowLines);
    if (b.dataset.view === "system") showSys(sysTab);
  }));
$("panel-close").onclick = () => $("panel").classList.add("hidden");

// ---------- data ----------
async function load() {
  const r = await fetch("/api/state");
  if (!r.ok) { $("loaded").textContent = "fout bij laden: " + r.status; return; }
  S = await r.json();
  try {
    index();
    renderAll();
  } catch (e) {
    console.error(e);
    $("loaded").innerHTML = `<span style="color:var(--bad)">JS-fout: ${esc(e.message)} (${esc((e.stack || "").split("\n")[1] || "")})</span>`;
  }
}

// afgeleide opzoektabellen
let byAddr, matrix, srcUse, chanUse;
function index() {
  byAddr = Object.fromEntries(S.nodes.map((n) => [n.addr, n]));
  matrix = Object.fromEntries(S.matrix.map((m) => [m.number, m]));
  // welke modules / bestemmingen gebruiken een matrix-bron
  srcUse = {};
  const add = (k, v) => (srcUse[k] ||= []).push(v);
  S.modules.forEach((m) => new Set(m.sources).forEach((s) => s > 0 && add(s, { type: "module", m })));
  S.dests.forEach((d) => d.source > 0 && add(d.source, { type: "dest", d }));
  // welke kaartkanalen gebruikt worden: "addr:ch" -> [{dir, owner, side}]
  chanUse = {};
  const use = (addr, ch, v) => addr && ch && (chanUse[addr + ":" + ch] ||= []).push(v);
  S.sources.forEach((s) => { use(s.input1_addr, s.input1_sub_ch, { dir: "in", s, side: "L" }); use(s.input2_addr, s.input2_sub_ch, { dir: "in", s, side: "R" }); });
  S.dests.forEach((d) => { use(d.output1_addr, d.output1_sub_ch, { dir: "out", d, side: "L" }); use(d.output2_addr, d.output2_sub_ch, { dir: "out", d, side: "R" }); });
}
const label = (num) => (num === 0 ? "none" : matrix[num]?.label ?? "#" + num);
const cardKind = (n) => (n.inputs > 0 ? "in" : n.outputs > 0 ? "out" : "other");
const issuesFor = (kind, ref) => S.issues.filter((i) => i.kind === kind && i.ref === ref && i.level !== "info");

function renderAll() {
  const g = S.global_config;
  const clock = g.ext_clock_addr ? (byAddr[g.ext_clock_addr]?.name ?? hex(g.ext_clock_addr)) : "intern";
  $("global").textContent = `${(g.samplerate / 1000).toFixed(1)} kHz · headroom ${g.headroom} dB · klok: ${clock} · ${S.dsp_count} DSP`;
  $("loaded").textContent = "geladen " + S.loaded_at;
  const bad = S.issues.filter((i) => i.level === "error").length;
  $("issue-count").textContent = bad || "";
  renderRack(); renderFlow(); renderFunctions(); renderModules(); renderBusses(); renderIssues(); renderLog();
}

// ---------- rack ----------
function renderRack() {
  const slotted = S.nodes.filter((n) => n.slot_nr != null);
  // kaartslots 1 .. ENGINE_SLOT-1, daarna de (brede) engine in ENGINE_SLOT
  const nSlots = Math.max(ENGINE_SLOT - 1, ...slotted.map((n) => n.slot_nr));
  const rack = $("rack");
  const engine = S.nodes.find((n) => n.system === "Engine");
  rack.style.setProperty("--slots", nSlots + ENGINE_WIDTH);
  rack.innerHTML = '<div class="ear l"><i></i><i></i></div><div class="rail"></div>';
  for (let i = 1; i <= nSlots; i++) {
    const n = slotted.find((x) => x.slot_nr === i);
    const el = document.createElement("div");
    if (!n) { el.className = "slot"; el.textContent = i; rack.append(el); continue; }
    // brede kaarten (bijv. voeding) beslaan fysiek meerdere slots
    let w = 1;
    while (w < cardWidth(n) && i + w <= nSlots && !slotted.some((x) => x.slot_nr === i + w)) w++;
    if (w > 1) {
      el.style.gridColumn = `span ${w}`;
      i += w - 1;
    }
    // kanalen: aantal volgens slot_config, maar ook kanalen die bronnen/bestemmingen gebruiken
    const used = Object.keys(chanUse).filter((k) => +k.split(":")[0] === n.addr).map((k) => +k.split(":")[1]);
    const count = Math.max(n.inputs, n.outputs, ...used, 0);
    const leds = [];
    for (let c = 1; c <= Math.min(count, 32); c++) {
      const u = chanUse[n.addr + ":" + c];
      const max = Math.max(n.inputs, n.outputs);
      leds.push(`<span class="led ${u ? (c > max ? "broken" : "used") : ""}" title="kanaal ${c}${u ? " → " + u.map((x) => esc((x.s || x.d).label)).join(", ") : ""}"></span>`);
    }
    const hasProblem = !n.active || issuesForNode(n).length;
    el.className = `slot card ${cardKind(n)} ${hasProblem ? "bad" : ""}`;
    el.innerHTML = `<span class="nr">${n.slot_nr}${w > 1 ? "–" + (n.slot_nr + w - 1) : ""}</span><span class="name">${esc(n.name)}</span>
      <span class="leds">${leds.join("")}</span><span class="addr">${hex(n.addr).slice(-4)}</span>`;
    el.title = `${n.name}\nadres ${hex(n.addr)}\n${n.inputs} in / ${n.outputs} uit`;
    el.onclick = () => showNode(n);
    rack.append(el);
  }
  // de engine zit fysiek altijd helemaal rechts in het rack (slot ENGINE_SLOT)
  if (!engine) {
    rack.insertAdjacentHTML("beforeend", `<div class="slot" style="grid-column: span ${ENGINE_WIDTH}">${ENGINE_SLOT}</div>`);
  } else {
    const el = document.createElement("div");
    el.className = `slot card engine ${engine.active ? "" : "bad"}`;
    el.style.gridColumn = `span ${ENGINE_WIDTH}`;
    el.innerHTML = `<span class="nr">${ENGINE_SLOT}</span><span class="name">${esc(engine.name)}</span>
      <span class="dot ${engine.active ? "on" : "off"}"></span>
      <span class="addr">${hex(engine.addr).slice(-4)}</span>`;
    el.title = `${engine.name}\nadres ${hex(engine.addr)}\n${S.dsp_count} DSP · ${(S.global_config.samplerate / 1000).toFixed(1)} kHz`;
    el.onclick = () => showNode(engine);
    rack.append(el);
  }
  rack.insertAdjacentHTML("beforeend", '<div class="rail b"></div><div class="ear r"><i></i><i></i></div>');
  $("other-nodes").innerHTML = "";
  S.nodes.filter((n) => n.slot_nr == null && n !== engine).forEach((n) => {
    const el = document.createElement("div");
    el.className = "node";
    el.innerHTML = `<div><span class="dot ${n.active ? "on" : "off"}"></span> <b>${esc(n.name)}</b><br>
      <small>${n.system ? "systeem: " + n.system : n.surface ? "surface" : "niet in rack"} · ${hex(n.addr)}</small></div>
      <small>${n.objects} obj.<br>${n.config_cnt} cfg</small>`;
    el.onclick = () => showNode(n);
    $("other-nodes").append(el);
  });
  $("consoles").innerHTML = S.consoles.map((c) => `<div class="console"><b>Console ${c.number}: ${esc(c.name)}</b><br>
    <small>${esc(c.location)} · ${esc(c.contact)} · ${S.modules.filter((m) => m.console === c.number).length} modules</small></div>`).join("");
}
// fysieke breedte in slots per kaarttype ("man:prod"); standaard 1
const CARD_WIDTH = {
  "1:22": 3,   // Rack-PWR (voeding) beslaat 3 slots (1–3)
};
const cardWidth = (n) => CARD_WIDTH[`${n.man}:${n.prod}`] || 1;
const RACK_SLOTS = 20;    // totaal aantal slots in het rack
const ENGINE_SLOT = 20;   // de engine zit in het laatste slot...
const ENGINE_WIDTH = 2;   // ...en is 2 keer zo breed als een normaal slot

function issuesForNode(n) {
  const bad = [];
  S.sources.forEach((s) => [[s.input1_addr, s.input1_sub_ch], [s.input2_addr, s.input2_sub_ch]].forEach(([a, c]) => a === n.addr && c > n.inputs && bad.push(s)));
  S.dests.forEach((d) => [[d.output1_addr, d.output1_sub_ch], [d.output2_addr, d.output2_sub_ch]].forEach(([a, c]) => a === n.addr && c > n.outputs && bad.push(d)));
  return bad;
}

// ---------- detailpaneel ----------
function showNode(n) {
  const chans = Object.entries(chanUse).filter(([k]) => +k.split(":")[0] === n.addr)
    .sort((a, b) => a[0].split(":")[1] - b[0].split(":")[1]);
  const max = Math.max(n.inputs, n.outputs);
  $("panel-body").innerHTML = `<h3>${esc(n.name)}</h3>
    <p><span class="dot ${n.active ? "on" : "off"}"></span> ${n.active ? "online" : "offline"}${n.system ? " · systeem-node (" + n.system + ")" : n.surface ? " · surface (bedieningspaneel)" : ""}</p>
    <dl>
      <dt>Slot</dt><dd>${n.slot_nr ?? "–"}</dd>
      <dt>MambaNet-adres</dt><dd><code>${hex(n.addr)}</code></dd>
      <dt>Unique ID</dt><dd><code>${n.unique_id}</code></dd>
      <dt>Firmware major</dt><dd>${n.firm_major}</dd>
      <dt>Inputs / outputs</dt><dd>${n.inputs} / ${n.outputs} <small>(slot_config)</small></dd>
      <dt>Objecten</dt><dd>${n.objects} (template)</dd>
      <dt>Geconfigureerd</dt><dd>${n.config_cnt} functies, ${n.default_cnt} defaults</dd>
      <dt>Eerst gezien</dt><dd>${n.firstseen.slice(0, 16)}</dd>
      <dt>Laatst gezien</dt><dd>${n.lastseen.slice(0, 16)}</dd>
    </dl>
    <h4>Gebruikte kanalen</h4>
    ${chans.length ? "<ul>" + chans.map(([k, us]) => {
      const c = +k.split(":")[1];
      return `<li ${c > max ? 'style="color:var(--bad)"' : ""}>kanaal ${c}: ${us.map((u) => (u.dir === "in" ? "bron " : "bestemming ") + "<b>" + esc((u.s || u.d).label) + "</b> (" + u.side + ")").join(", ")}
        ${c > max ? "<br><small>buiten het aantal kanalen in slot_config (" + max + ")</small>" : ""}</li>`;
    }).join("") + "</ul>" : '<p class="empty">Geen bronnen of bestemmingen gekoppeld.</p>'}`;
  $("panel").classList.remove("hidden");
}
function showSource(s) {
  const uses = srcUse[s.number + 288] || [];
  $("panel-body").innerHTML = `<h3>Bron: ${esc(s.label)}</h3>
    <dl><dt>Nummer</dt><dd>${s.number} <small>(matrix ${s.number + 288})</small></dd>
      <dt>Input L</dt><dd>${chanText(s.input1_addr, s.input1_sub_ch)}</dd>
      <dt>Input R</dt><dd>${chanText(s.input2_addr, s.input2_sub_ch)}</dd>
      <dt>Gain</dt><dd>${s.input_gain} dB${s.input_phantom ? " · phantom" : ""}${s.input_pad ? " · pad" : ""}</dd></dl>
    <h4>Gebruikt door</h4>${uses.length ? "<ul>" + uses.map((u) => u.type === "module"
      ? `<li>Module ${u.m.number} (console ${u.m.console})</li>` : `<li>Bestemming <b>${esc(u.d.label)}</b></li>`).join("") + "</ul>"
      : '<p class="empty">Nergens gebruikt.</p>'}
    ${issueList(issuesFor("Bron", s.number))}`;
  $("panel").classList.remove("hidden");
}
function showDest(d) {
  $("panel-body").innerHTML = `<h3>Bestemming: ${esc(d.label)}</h3>
    <dl><dt>Nummer</dt><dd>${d.number}</dd>
      <dt>Output L</dt><dd>${chanText(d.output1_addr, d.output1_sub_ch)}</dd>
      <dt>Output R</dt><dd>${chanText(d.output2_addr, d.output2_sub_ch)}</dd>
      <dt>Signaal</dt><dd>${esc(label(d.source))} <small>(${matrix[d.source]?.type ?? "-"})</small></dd>
      <dt>Niveau</dt><dd>${db(d.level)}</dd>
      <dt>N-1 van</dt><dd>${esc(label(d.mix_minus_source))}</dd>
      <dt>Routing</dt><dd>${["stereo", "links", "rechts", "mono"][d.routing] ?? d.routing}</dd></dl>
    ${issueList(issuesFor("Bestemming", d.number))}`;
  $("panel").classList.remove("hidden");
}
function chanText(addr, ch) {
  if (!addr && !ch) return '<span class="empty">niet gekoppeld</span>';
  const n = byAddr[addr];
  return n ? `${esc(n.name)} · slot ${n.slot_nr ?? "–"} · kanaal ${ch}` : `onbekend adres ${hex(addr)} · kanaal ${ch}`;
}
const issueList = (list) => list.length ? `<h4>Problemen</h4>` + list.map(issueHTML).join("") : "";
const issueHTML = (i) => `<div class="issue ${i.level}"><span class="lv">${{ error: "fout", warn: "let op", info: "info" }[i.level]}</span><span>${esc(i.text)}</span></div>`;

// ---------- signaalpad ----------
let flowEdges = [];
function renderFlow() {
  const box = (id, cls, title, sub, onclick) => ({ id, cls, title, sub, onclick });
  const cols = [[], [], [], [], []];
  flowEdges = [];
  const seen = new Set();
  const once = (col, b) => { if (!seen.has(b.id)) { seen.add(b.id); cols[col].push(b); } };
  const chanBox = (dir, addr, c1, c2) => {
    const n = byAddr[addr];
    const max = n ? (dir === "in" ? n.inputs : n.outputs) : 0;
    const bad = !n || !n.active || n.slot_nr == null || c1 > max || c2 > max;
    const id = `${dir}-${addr}-${c1}-${c2}`;
    once(dir === "in" ? 0 : 4, box(id, (dir === "in" ? "in" : "out") + (bad ? " bad" : ""),
      n ? `${esc(n.name)}` : "adres " + hex(addr || 0),
      `slot ${n?.slot_nr ?? "–"} · kanaal ${c1}${c2 !== c1 ? "/" + c2 : ""}`, () => n && showNode(n)));
    return [id, bad];
  };
  S.sources.forEach((s) => {
    const sid = "src-" + s.number;
    once(1, box(sid, issuesFor("Bron", s.number).length ? "bad" : "", esc(s.label), `bron ${s.number}`, () => showSource(s)));
    if (s.input1_addr || s.input1_sub_ch) {
      const [cid, bad] = chanBox("in", s.input1_addr, s.input1_sub_ch, s.input2_sub_ch);
      flowEdges.push([cid, sid, bad]);
    }
    S.modules.filter((m) => m.sources.includes(s.number + 288)).forEach((m) => {
      once(2, box("mod-" + m.number, "", `Module ${m.number}`, `console ${m.console}`, null));
      flowEdges.push([sid, "mod-" + m.number, false]);
    });
  });
  S.dests.forEach((d) => {
    const did = "dst-" + d.number;
    once(3, box(did, issuesFor("Bestemming", d.number).length ? "bad" : "", esc(d.label), `bestemming ${d.number}`, () => showDest(d)));
    const t = matrix[d.source]?.type;
    if (t === "source") flowEdges.push(["src-" + (d.source - 288), did, false]);
    else if (d.source > 0) {
      const bid = "bus-" + d.source;
      once(2, box(bid, matrix[d.source]?.active === false ? "dim" : "", esc(label(d.source)), t, null));
      flowEdges.push([bid, did, false]);
      if (t === "buss") S.modules.filter((m) => m.busses[d.source - 1]?.assigned && cols[2].some((b) => b.id === "mod-" + m.number))
        .forEach((m) => flowEdges.push(["mod-" + m.number, bid, false]));
    }
    if (d.output1_addr || d.output1_sub_ch) {
      const [cid, bad] = chanBox("out", d.output1_addr, d.output1_sub_ch, d.output2_sub_ch);
      flowEdges.push([did, cid, bad]);
    }
  });
  const heads = ["Kaart-inputs (fysiek)", "Bronnen", "Modules & bussen", "Bestemmingen", "Kaart-outputs (fysiek)"];
  const flow = $("flow");
  flow.innerHTML = '<svg id="flow-svg"></svg>' + cols.map((c, i) =>
    `<div class="col"><h3>${heads[i]}</h3>${c.map((b) => `<div class="fbox ${b.cls}" id="${b.id}"><b>${b.title}</b><small>${esc(b.sub)}</small></div>`).join("") || '<span class="empty">–</span>'}</div>`).join("");
  cols.flat().forEach((b) => {
    const el = $(b.id);
    if (b.onclick) el.onclick = b.onclick;
    el.onmouseenter = () => highlight(b.id, true);
    el.onmouseleave = () => highlight(b.id, false);
  });
  requestAnimationFrame(drawFlowLines);
}
function drawFlowLines() {
  const svg = $("flow-svg"); if (!svg) return;
  const base = $("flow").getBoundingClientRect();
  if (!base.width) return;
  svg.innerHTML = flowEdges.map(([a, b, bad], i) => {
    const ea = $(a), eb = $(b); if (!ea || !eb) return "";
    const ra = ea.getBoundingClientRect(), rb = eb.getBoundingClientRect();
    const x1 = ra.right - base.left, y1 = ra.top + ra.height / 2 - base.top;
    const x2 = rb.left - base.left, y2 = rb.top + rb.height / 2 - base.top;
    const dx = (x2 - x1) / 2;
    return `<path data-a="${a}" data-b="${b}" class="${bad ? "bad" : ""}" d="M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}"/>`;
  }).join("");
}
function highlight(id, on) {
  // markeer de hele keten links en rechts van dit blok
  const ids = new Set([id]);
  const walk = (cur, dirKey, otherKey) => flowEdges.forEach((e) => { if (e[dirKey] === cur && !ids.has(e[otherKey])) { ids.add(e[otherKey]); walk(e[otherKey], dirKey, otherKey); } });
  walk(id, 0, 1); walk(id, 1, 0);
  document.querySelectorAll("#flow-svg path").forEach((p) => p.classList.toggle("hl", on && ids.has(p.dataset.a) && ids.has(p.dataset.b)));
  ids.forEach((i) => $(i)?.classList.toggle("hl", on));
}
window.addEventListener("resize", () => requestAnimationFrame(drawFlowLines));

// ---------- kaart-functies / import-offset ----------
function renderFunctions() {
  const typeCls = (t) => ({ 0: "t-mod", 1: "t-bus", 2: "t-bus", 3: "t-con", 5: "t-src", 6: "t-dst" }[t] || "");
  const chip = (f) => `<span class="chip ${typeCls(f.type)}">${esc(f.target)}</span>`;
  $("functions").innerHTML = S.functions.map((n) => {
    const imps = n.imports.map((i) => {
      const pos = i.positions.length ? `posities ${i.positions.join(", ")}` : "";
      let head;
      const sign = (o) => (o > 0 ? "+" : "") + o;
      const advice = i.missing?.length
        ? `<span class="warnline">Er zijn op dit moment geen ${esc(i.missing.join(" en "))} in de database.</span>
           <small>Maak eerst de ${esc(i.missing.join(" en "))} aan; daarna kan de juiste offset berekend worden.</small>`
        : i.partial
        ? `Beste offset: <span class="big warnc">${sign(i.suggestion)}</span>
           <small>Geen offset klopt volledig: ${i.partial_bad} objecten blijven fout. Deze import bevat ${esc((i.mixed || []).join(" én "))},
           en de Perl-pagina past één offset op alles toe.</small>`
        : `Juiste offset: <span class="big">${sign(i.suggestion)}</span>`;
      if (i.status === "fout")
        head = `<div class="imp fout"><b>✗ Import "${esc(i.cfg_name)}" is uitgevoerd met offset ${sign(i.matched_offset)}</b>
          <p>Deze import gebruikt ${esc(i.pos_kind)}-${pos}. Met offset ${sign(i.matched_offset)} bestaan die posities niet,
          en dan koppelt de Perl-pagina ze <b>zonder melding</b> aan de eerste ${esc(i.pos_kind)}.
          ${i.bad_objects?.length ?? 0} objecten zijn zo verkeerd terechtgekomen (rood in de tabel).</p>
          <p class="fix">${advice}</p></div>`;
      else if (i.status === "ok")
        head = `<div class="imp ok"><b>✓ Komt overeen met import "${esc(i.cfg_name)}" offset ${sign(i.matched_offset)}</b>
          <small>${pos}</small></div>`;
      else
        head = `<div class="imp geen"><b>Import "${esc(i.cfg_name)}" (niet gebruikt)</b> <small>${i.count} functies${pos ? ", " + pos : ""}</small>
          <p class="fix">${advice}</p></div>`;
      return { i, head };
    });
    // vergelijkingstabel: huidig vs. voorbeeld met voorgestelde offset (van de eerste import met een voorstel)
    const best = (imps.find((x) => x.i.status === "fout") || imps.find((x) => x.i.status === "geen" && !n.functions.length))?.i;
    const bad = new Set(n.imports.flatMap((i) => i.bad_objects || []));
    const objects = [...new Set([...n.functions.map((f) => f.object), ...Object.keys(best?.preview || {}).map(Number)])].sort((a, b) => a - b);
    const cur = Object.fromEntries(n.functions.map((f) => [f.object, f]));
    const table = objects.length ? `<div class="scroll"><table class="ft">
      <tr><th>Object</th><th>Beschrijving</th><th>Functie</th><th>Nu gekoppeld aan</th>${best ? `<th>Met offset ${best.suggestion}</th>` : ""}</tr>
      ${objects.map((o) => {
        const f = cur[o], p = best?.preview?.[o];
        const desc = f?.description ?? p?.description ?? "";
        return `<tr class="${bad.has(o) ? "badrow" : ""}"><td><code>${o}</code></td><td>${esc(desc)}</td>
          <td>${esc(f?.name ?? p?.name ?? "")}</td><td>${f ? chip(f) : '<span class="empty">–</span>'}</td>
          ${best ? `<td>${p ? chip(p) : ""}</td>` : ""}</tr>`;
      }).join("")}</table></div>` : '<p class="empty">Nog geen functies gekoppeld.</p>';
    return `<div class="fnode"><h3>${esc(n.name)} <small>${n.slot_nr ? "slot " + n.slot_nr : "niet in rack"} · ${hex(n.addr)} · ${n.functions.length} functies</small></h3>
      ${imps.map((x) => x.head).join("")}${table}</div>`;
  }).join("") || '<p class="empty">Geen kaarten met functies.</p>';
}

// ---------- modules ----------
function renderModules() {
  const consoles = [...new Set(S.modules.map((m) => m.console))].sort();
  if (!consoles.includes(consoleSel)) consoleSel = consoles[0];
  $("console-filter").innerHTML = consoles.map((c) => `<button data-c="${c}" class="${c === consoleSel ? "active" : ""}">Console ${c} <small>(${S.modules.filter((m) => m.console === c).length})</small></button>`).join("");
  $("console-filter").querySelectorAll("button").forEach((b) => (b.onclick = () => { consoleSel = +b.dataset.c; renderModules(); }));
  const busLbl = Object.fromEntries(S.busses.map((b) => [b.number, b.label]));
  $("modules").innerHTML = S.modules.filter((m) => m.console === consoleSel).map((m) => {
    const pos = Math.max(0, Math.min(1, (m.mod_level + 60) / 70));  // -60..+10 dB
    return `<div class="strip ${m.mod_on_off ? "on" : ""}">
      <div class="title">${m.number}</div>
      <div class="src">${m.sources.map((s, i) => `<b>${"ABCDEFGH"[i]}</b><span class="${s ? "" : "none"}" title="${esc(label(s))}">${esc(label(s))}</span>`).join("")}</div>
      <div class="bus">${m.busses.map((b, i) => `<i class="${b.assigned ? "a" : ""} ${b.assigned && b.on ? "on" : ""}" title="${esc(busLbl[i + 1] ?? "bus " + (i + 1))}: ${b.assigned ? (b.on ? "aan" : "toegewezen, uit") : "niet toegewezen"} · ${db(b.level)}">${esc((busLbl[i + 1] ?? "").slice(0, 3))}</i>`).join("")}</div>
      <div class="fader" title="module-niveau"><i style="bottom:calc(${pos * 100}% - 5px)"></i></div>
      <div class="lvl">${db(m.mod_level)}</div>
      <div class="lvl">${m.eq_on_off ? "EQ " : ""}${m.dyn_on_off ? "DYN" : ""}</div>
    </div>`;
  }).join("") || '<p class="empty">Geen modules voor deze console.</p>';
}

// ---------- bussen ----------
function renderBusses() {
  $("busses").innerHTML = S.busses.map((b) => {
    const pos = Math.max(0, Math.min(1, (b.level + 60) / 70));
    return `<div class="buscard"><span class="lbl">${esc(b.label)}</span> <small>bus ${b.number * 2 - 1}/${b.number * 2} · console ${b.console}</small>
      <small>${b.on_off ? "aan" : "uit"} · ${b.pre_on ? "pre" : "post"} · ${db(b.level)}${b.interlock ? " · interlock" : ""}${b.exclusive ? " · exclusive" : ""}${b.mono ? " · mono" : ""}</small>
      <div class="meter"><i style="width:${pos * 100}%"></i></div></div>`;
  }).join("");
  const dsp = S.dsp_count * 4;
  $("monitor").innerHTML = `<div class="scroll"><table class="mx"><tr><th class="l">Monitorbus</th><th>Console</th>${S.busses.map((b) => `<th class="v">${esc(b.label)}</th>`).join("")}<th>Dim</th></tr>
    ${S.monitor.map((m) => `<tr style="${m.number > dsp ? "opacity:.45" : ""}"><td class="l">${m.number}. ${esc(m.label)}</td><td>${m.console}</td>
      ${m.busses.map((v) => `<td class="${v ? "y" : ""}">${v ? "●" : ""}</td>`).join("")}<td>${db(m.dim_level)}</td></tr>`).join("")}
  </table></div><p class="empty">Grijs = niet actief (meer monitorbussen dan ${S.dsp_count} DSP-kaart(en) aankunnen).</p>`;
}

// ---------- problemen ----------
function renderIssues() {
  const order = { error: 0, warn: 1, info: 2 };
  const list = [...S.issues].sort((a, b) => order[a.level] - order[b.level]);
  $("issues").innerHTML = list.length ? list.map(issueHTML).join("") : '<p class="empty">Geen problemen gevonden.</p>';
}

// ---------- live log ----------
function renderLog(fresh = 0) {
  $("log").innerHTML = S.changes.map((c, i) => `<div class="${i < fresh ? "new" : ""}"><span>${c.ts.slice(11, 19)}</span>${esc(c.change)} <b>${esc(c.arguments)}</b></div>`).join("")
    || '<div class="empty">Geen wijzigingen in het afgelopen uur.</div>';
}

// ---------- systeem ----------
let sysTab = "mambanet";
const sysCache = {};
const yn = (v) => (v ? '<span class="yes">●</span>' : '<span class="no">○</span>');
const uid = (m, p, i) => [m, p, i].map((x) => x.toString(16).toUpperCase().padStart(4, "0")).join(":");
const LEVELS = ["Idle", "Onbekend", "Operator 1", "Operator 2", "Supervisor 1", "Supervisor 2"];
document.querySelectorAll("#sys-tabs button").forEach((b) => (b.onclick = () => showSys(b.dataset.sys)));

async function sysGet(path, fresh = false) {
  if (!fresh && sysCache[path]) return sysCache[path];
  const r = await fetch("/api/system/" + path);
  const data = await r.json();
  if (!r.ok) throw new Error(data.detail || r.status);
  return (sysCache[path] = data);
}

async function showSys(tab, fresh = false) {
  sysTab = tab;
  document.querySelectorAll("#sys-tabs button").forEach((x) => x.classList.toggle("active", x.dataset.sys === tab));
  const body = $("sys-body");
  body.innerHTML = '<p class="empty">laden…</p>';
  try { await SYS[tab](body, fresh); }
  catch (e) { body.innerHTML = `<div class="issue error"><span class="lv">fout</span><span>${esc(e.message)}</span></div>`; }
}

const table = (head, rows) => `<div class="scroll"><table class="st"><tr>${head.map((h) => `<th>${h}</th>`).join("")}</tr>${rows.join("")}</table></div>`;

const SYS = {
  async mambanet(body, fresh) {
    const d = await sysGet("mambanet", fresh);
    body.innerHTML = table(["", "Adres", "Unique ID", "Naam", "Slot", "Parent", "Engine", "Services", "User level", "Objecten", "Config", "Defaults", "Firmware", "Adresaanvragen", "Eerst gezien", "Laatst gezien"],
      d.map((n) => `<tr class="${n.active ? "" : "inactive"}"><td><span class="dot ${n.active ? "on" : "off"}"></span></td>
        <td><code>${hex(n.addr)}</code></td><td><code>${uid(n.man, n.prod, n.uid)}</code></td><td><b>${esc(n.name)}</b></td>
        <td>${n.slot_nr ?? "–"}</td><td>${esc(n.parent_name ?? uid(n.p_man, n.p_prod, n.p_id))}</td><td><code>${hex(n.engine_addr)}</code></td>
        <td>${n.services}</td><td>${n.user_level_from_console ? "console " + n.user_level_from_console : "–"}</td>
        <td>${n.objects}</td><td>${n.config_cnt}</td><td>${n.default_cnt}</td><td>${n.firm_major}</td><td>${n.addr_requests}</td>
        <td>${n.firstseen.slice(0, 16)}</td><td>${n.lastseen.slice(0, 16)}</td></tr>`));
  },
  async register(body, fresh) {
    const d = (await sysGet("mambanet", fresh)).filter((n) => n.slot_nr != null).sort((a, b) => a.slot_nr - b.slot_nr);
    body.innerHTML = table(["Slot", "Naam", "Unique ID (hex)", "Unique ID (dec)"],
      d.map((n) => `<tr class="${n.active ? "" : "inactive"}"><td>${n.slot_nr}</td><td><b>${esc(n.name)}</b></td>
        <td><code>${uid(n.man, n.prod, n.uid)}</code></td><td><code>${n.man}.${n.prod}.${n.uid}</code></td></tr>`));
  },
  async templates(body, fresh) {
    const d = await sysGet("templates", fresh);
    body.innerHTML = `<p class="empty">Klik op een template voor alle objecten (sensoren/actuatoren) van dat kaarttype.</p>` +
      table(["Fabrikant", "Product", "Firmware", "Objecten", "Gebruikt door", "Aantal nodes"],
        d.map((t) => `<tr class="click" data-k="${t.man_id}/${t.prod_id}/${t.firm_major}"><td><code>${hex(t.man_id).slice(-4)}</code></td>
          <td><code>${hex(t.prod_id).slice(-4)}</code></td><td>${t.firm_major}</td><td>${t.count}</td>
          <td>${esc(t.node_name ?? "–")}</td><td>${t.nodes}</td></tr>`)) + '<div id="tpl-detail"></div>';
    body.querySelectorAll("tr.click").forEach((tr) => (tr.onclick = async () => {
      body.querySelectorAll("tr.click").forEach((x) => x.classList.toggle("sel", x === tr));
      const rows = await sysGet("templates/" + tr.dataset.k);
      const hasCnt = rows.some((r) => r.description === "Input channel count");
      $("tpl-detail").innerHTML = `<h3>Template ${esc(tr.dataset.k.replaceAll("/", " · "))} <small>${rows.length} objecten</small></h3>
        <p class="${hasCnt ? "" : "warnline"}">${hasCnt ? "✓ Dit kaarttype meldt zijn kanaalaantal (object 1025/1026)." : "✗ Dit kaarttype heeft géén object \"Input/Output channel count\": de engine kan het aantal kanalen niet uitlezen."}</p>` +
        table(["Object", "Beschrijving", "Services", "Sensor", "Bereik", "Actuator", "Bereik", "Standaard"],
          rows.map((r) => `<tr class="${/channel count|Slot number/.test(r.description) ? "hlrow" : ""}"><td><code>${r.number}</code></td><td>${esc(r.description)}</td><td>${r.services}</td>
            <td>${r.sensor_type ? esc(r.sensor) : '<span class="empty">–</span>'}</td><td>${esc(r.sensor_range)}</td>
            <td>${r.actuator_type ? esc(r.actuator) : '<span class="empty">–</span>'}</td><td>${esc(r.actuator_range)}</td><td>${r.actuator_default ?? ""}</td></tr>`));
      $("tpl-detail").scrollIntoView({ behavior: "smooth" });
    }));
  },
  async predefined(body, fresh) {
    const d = await sysGet("predefined", fresh);
    const nodes = (await sysGet("mambanet")).reduce((m, n) => ((m[`${n.man}/${n.prod}/${n.firm_major}`] ||= []).push(n.name), m), {});
    body.innerHTML = `<p class="empty">Opgeslagen functie-sets die je in Rack-configuratie kunt importeren. Zie het tabblad Kaart-functies voor de juiste offset.</p>` +
      table(["Fabrikant", "Product", "Firmware", "Naam", "Functies", "Defaults", "Past op kaart(en)"],
        d.map((p) => `<tr><td><code>${hex(p.man_id).slice(-4)}</code></td><td><code>${hex(p.prod_id).slice(-4)}</code></td><td>${p.firm_major}</td>
          <td><b>${esc(p.cfg_name)}</b></td><td>${p.config}</td><td>${p.defaults}</td>
          <td>${esc((nodes[`${p.man_id}/${p.prod_id}/${p.firm_major}`] || []).join(", ")) || '<span class="empty">geen</span>'}</td></tr>`));
  },
  async functions(body, fresh) {
    const d = await sysGet("functions", fresh);
    const types = [...new Set(d.map((f) => f.type))];
    const TN = { 0: "Module", 1: "Bus", 2: "Monitorbus", 3: "Console", 4: "Globaal", 5: "Bron", 6: "Bestemming" };
    body.innerHTML = `<div class="toolbar"><div class="seg" id="ft-types">${types.map((t, i) => `<button data-t="${t}" class="${i ? "" : "active"}">${TN[t] ?? t} <small>(${d.filter((f) => f.type === t).length})</small></button>`).join("")}</div>
      <input id="ft-search" type="search" placeholder="zoek functie…"></div><div id="ft-table"></div>`;
    let type = types[0];
    const draw = () => {
      const q = $("ft-search").value.toLowerCase();
      const rows = d.filter((f) => (q ? true : f.type === type) && (!q || f.name.toLowerCase().includes(q) || (f.label || "").toLowerCase().includes(q)));
      $("ft-table").innerHTML = table(["Soort", "Nr", "Functie", "Label", "Ontvangt", "Zendt", ...LEVELS],
        rows.map((f) => `<tr><td>${TN[f.type] ?? f.type}</td><td>${f.func}</td><td><b>${esc(f.name)}</b></td><td>${esc(f.label)}</td>
          <td>${esc(f.rcv)}</td><td>${esc(f.xmt)}</td>${[0, 1, 2, 3, 4, 5].map((l) => `<td class="c">${f.rcv_type ? yn(f["user_level" + l]) : ""}</td>`).join("")}</tr>`));
    };
    body.querySelectorAll("#ft-types button").forEach((b) => (b.onclick = () => {
      type = +b.dataset.t; $("ft-search").value = "";
      body.querySelectorAll("#ft-types button").forEach((x) => x.classList.toggle("active", x === b)); draw();
    }));
    $("ft-search").oninput = draw;
    draw();
  },
  async logs(body) {
    const names = { engine: "Engine", gateway: "Gateway", address: "Address server", learner: "Learner", postgresql: "PostgreSQL" };
    body.innerHTML = `<div class="toolbar"><div class="seg" id="lg-names">${Object.entries(names).map(([k, v], i) => `<button data-n="${k}" class="${i ? "" : "active"}">${v}</button>`).join("")}</div>
      <select id="lg-lines"><option>200</option><option selected>500</option><option>2000</option><option>5000</option></select>
      <input id="lg-filter" type="search" placeholder="filter, bijv. 0x00000001 of slot">
      <button id="lg-reload" class="btn">Vernieuwen</button></div><div id="lg-info" class="empty"></div><pre id="lg-text" class="logtext"></pre>`;
    let name = "engine", data = null;
    const draw = () => {
      const q = $("lg-filter").value.toLowerCase();
      const lines = q ? data.lines.filter((l) => l.toLowerCase().includes(q)) : data.lines;
      $("lg-info").textContent = `${data.file}: laatste ${data.lines.length} van ${data.total} regels${q ? `, ${lines.length} gevonden` : ""}`;
      $("lg-text").innerHTML = lines.map((l) => {
        const cls = /error|fail|wrong|timeout/i.test(l) ? "le" : /warn|retr/i.test(l) ? "lw" : "";
        return `<span class="${cls}">${esc(l)}</span>`;
      }).join("\n");
      $("lg-text").scrollTop = $("lg-text").scrollHeight;
    };
    const fetchLog = async () => {
      $("lg-info").textContent = "laden…";
      const r = await fetch(`/api/system/logs/${name}?lines=${$("lg-lines").value}`);
      data = await r.json();
      if (!r.ok) { $("lg-info").textContent = data.detail; return; }
      draw();
    };
    body.querySelectorAll("#lg-names button").forEach((b) => (b.onclick = () => {
      name = b.dataset.n; body.querySelectorAll("#lg-names button").forEach((x) => x.classList.toggle("active", x === b)); fetchLog();
    }));
    $("lg-lines").onchange = fetchLog; $("lg-reload").onclick = fetchLog; $("lg-filter").oninput = () => data && draw();
    fetchLog();
  },
  async versions(body, fresh) {
    const d = await sysGet("versions", fresh);
    body.innerHTML = table(["Pakket", "Versie", "Gebouwd", "Geïnstalleerd"],
      d.map((p) => `<tr><td><b>${esc(p.name)}</b></td><td><code>${esc(p.version)}</code></td><td>${esc(p.build)}</td><td>${esc(p.installed)}</td></tr>`));
  },
};

let reloadTimer = null;
function connectEvents() {
  const es = new EventSource("/api/events");
  es.addEventListener("hello", () => $("live").className = "dot on");
  es.addEventListener("change", (e) => {
    const items = JSON.parse(e.data);
    if (S && items.length) { S.changes = [...items.reverse(), ...S.changes].slice(0, 50); renderLog(items.length); }
    clearTimeout(reloadTimer);
    reloadTimer = setTimeout(load, 400);   // bundel snelle reeksen wijzigingen
  });
  es.onerror = () => ($("live").className = "dot off");
}

load();
if (!location.search.includes("nolive")) connectEvents();   // ?nolive = zonder live-updates (voor tests)
const startTab = new URLSearchParams(location.search).get("tab");
if (startTab) document.querySelector(`#tabs button[data-view="${startTab}"]`)?.click();
