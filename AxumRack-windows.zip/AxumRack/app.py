"""AXUM rack-visualizer: leest/schrijft de AXUM Postgres database en toont rack + signaalpaden.

Start:  .venv/bin/python app.py      -> open http://127.0.0.1:8090
Schrijven gaat via gewone UPDATEs; de triggers in de database zorgen dat axum-engine
de wijziging oppikt (zelfde mechanisme als de oude Perl-site en HeidiSQL).
"""
import os
from pathlib import Path

import psycopg
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

DB = dict(
    host=os.environ.get("AXUM_HOST", "192.168.1.222"),
    user=os.environ.get("AXUM_USER", "axum"),
    dbname=os.environ.get("AXUM_DB", "axum"),
    connect_timeout=5,
    client_encoding="latin1",
)
HERE = Path(__file__).parent
BUSS_PAIRS = [f"{2*i+1}_{2*i+2}" for i in range(16)]  # buss_1_2 .. buss_31_32 -> buss 1..16

app = FastAPI()


def rows(cur, sql, args=None):
    cur.execute(sql, args)
    cols = [d.name for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def mamba_id(s):
    man, prod, uid = (int(x) for x in str(s).strip("()").split(","))
    return {"man": man, "prod": prod, "id": uid}


@app.get("/")
def index():
    return FileResponse(HERE / "static" / "index.html")


@app.get("/api/state")
def state():
    with psycopg.connect(**DB) as c, c.cursor() as cur:
        nodes = rows(cur, "SELECT addr, name, id::text AS id, active, parent::text AS parent, firm_major, lastseen FROM addresses ORDER BY addr")
        for n in nodes:
            n["id"] = mamba_id(n["id"])
            n["parent"] = mamba_id(n["parent"])
            n["lastseen"] = n["lastseen"].isoformat() if n["lastseen"] else None
        slots = rows(cur, "SELECT slot_nr, addr, input_ch_cnt, output_ch_cnt FROM slot_config ORDER BY slot_nr")
        sources = rows(cur, """SELECT number, label, input1_addr, input1_sub_ch, input2_addr, input2_sub_ch,
                                      input_phantom, input_pad, input_gain FROM src_config ORDER BY pos""")
        dests = rows(cur, """SELECT number, label, output1_addr, output1_sub_ch, output2_addr, output2_sub_ch,
                                    level, source, mix_minus_source FROM dest_config ORDER BY pos""")
        busses = rows(cur, "SELECT number, label, on_off, level, console, mono FROM buss_config ORDER BY number")
        mon = rows(cur, "SELECT number, label, " + ", ".join(f"buss_{p}" for p in BUSS_PAIRS) + " FROM monitor_buss_config ORDER BY number")
        for m in mon:
            m["busses"] = [i + 1 for i, p in enumerate(BUSS_PAIRS) if m.pop(f"buss_{p}")]
        mod_cols = ", ".join(f"source_{x}" for x in "abcdefgh") + ", " + ", ".join(
            f"buss_{p}_assignment, buss_{p}_on_off" for p in BUSS_PAIRS)
        modules = rows(cur, f"SELECT number, console, mod_on_off, mod_level, {mod_cols} FROM module_config ORDER BY number")
        for m in modules:
            m["sources"] = [m.pop(f"source_{x}") for x in "abcdefgh"]
            m["busses"] = [{"buss": i + 1, "on": m.pop(f"buss_{p}_on_off")}
                           for i, p in enumerate(BUSS_PAIRS) if m.pop(f"buss_{p}_assignment")]
        matrix = rows(cur, "SELECT pos, type, number, label, active FROM matrix_sources ORDER BY pos")
        cur.execute("SELECT max(timestamp) FROM recent_changes")
        stamp = cur.fetchone()[0]
    return {"nodes": nodes, "slots": slots, "sources": sources, "dests": dests, "busses": busses,
            "monitor_busses": mon, "modules": modules, "matrix": matrix,
            "stamp": stamp.isoformat() if stamp else None}


@app.get("/api/stamp")
def stamp():
    """Goedkope poll: verandert zodra iemand (engine, oude site, HeidiSQL) iets wijzigt."""
    with psycopg.connect(**DB) as c, c.cursor() as cur:
        cur.execute("SELECT max(timestamp) FROM recent_changes")
        s = cur.fetchone()[0]
    return {"stamp": s.isoformat() if s else None}


class DestSource(BaseModel):
    source: int


class SrcInput(BaseModel):
    input1_addr: int
    input1_sub_ch: int
    input2_addr: int
    input2_sub_ch: int


class ModuleSource(BaseModel):
    source_a: int


def execute(sql, args):
    with psycopg.connect(**DB) as c, c.cursor() as cur:
        cur.execute(sql, args)
        if cur.rowcount != 1:
            raise HTTPException(404, "rij niet gevonden")
    return {"ok": True}


@app.post("/api/dest/{number}/source")
def set_dest_source(number: int, body: DestSource):
    return execute("UPDATE dest_config SET source = %s WHERE number = %s", (body.source, number))


@app.post("/api/src/{number}/input")
def set_src_input(number: int, b: SrcInput):
    return execute("""UPDATE src_config SET input1_addr=%s, input1_sub_ch=%s, input2_addr=%s, input2_sub_ch=%s
                      WHERE number=%s""", (b.input1_addr, b.input1_sub_ch, b.input2_addr, b.input2_sub_ch, number))


@app.post("/api/module/{number}/source")
def set_module_source(number: int, body: ModuleSource):
    return execute("UPDATE module_config SET source_a = %s WHERE number = %s", (body.source_a, number))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8090)
