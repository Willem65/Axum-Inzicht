@echo off
title AXUM Rack
cd /d "%~dp0"
rem IP-adres van de AXUM engine (pas aan indien nodig)
set AXUM_HOST=192.168.1.222
echo AXUM Rack start... sluit dit venster om te stoppen.
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8090"
python\python.exe app.py
pause
