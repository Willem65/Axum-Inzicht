@echo off
title AXUM Inzicht - koppelen met de engine
cd /d "%~dp0"

rem Maakt eenmalig een SSH-sleutel voor deze pc en zet die op de engine.
rem Daarna kan AXUM Inzicht zonder wachtwoord de engine-stand lezen en Live meekijken.

rem IP-adres van de engine: zelfde als in "Start AXUM Inzicht.bat"
set AXUM_ENGINE=192.168.1.222
for /f "tokens=2 delims==" %%a in ('findstr /b /c:"set AXUM_ENGINE=" "Start AXUM Inzicht.bat"') do set AXUM_ENGINE=%%a

set KEY=%USERPROFILE%\.ssh\id_rsa_axum
set OPTS=-o StrictHostKeyChecking=accept-new -o HostKeyAlgorithms=+ssh-rsa -o PubkeyAcceptedKeyTypes=+ssh-rsa -o ConnectTimeout=8

echo.
echo  AXUM Inzicht - koppelen met de engine (%AXUM_ENGINE%)
echo  -----------------------------------------------------
echo.

where ssh >nul 2>nul || (
  echo  FOUT: het programma "ssh" is niet gevonden.
  echo  Zet het aan via: Instellingen - Systeem - Optionele onderdelen - OpenSSH-client
  echo  en start dit bestand daarna opnieuw.
  pause
  exit /b 1
)

if not exist "%USERPROFILE%\.ssh" mkdir "%USERPROFILE%\.ssh"
if not exist "%KEY%" (
  echo  Sleutel aanmaken voor deze pc...
  ssh-keygen -q -t rsa -b 4096 -N "" -C "axum-inzicht@%COMPUTERNAME%" -f "%KEY%"
  if not exist "%KEY%" (
    echo  FOUT: de sleutel kon niet aangemaakt worden.
    pause
    exit /b 1
  )
)

rem Werkt de sleutel al? Dan zijn we klaar.
ssh -i "%KEY%" %OPTS% -o BatchMode=yes root@%AXUM_ENGINE% "echo ok" >nul 2>nul && (
  echo  Deze pc is al gekoppeld met de engine. Er hoeft niets meer te gebeuren.
  echo.
  pause
  exit /b 0
)

rem Openbare sleutel inlezen (een regel: "ssh-rsa AAAA... axum-inzicht@PC")
set PUB=
for /f "usebackq delims=" %%k in ("%KEY%.pub") do set PUB=%%k

echo  Typ hieronder het root-wachtwoord van de engine en druk op Enter.
echo  (Je ziet niets verschijnen terwijl je typt; dat is normaal.)
echo.
ssh %OPTS% root@%AXUM_ENGINE% "mkdir -p .ssh && chmod 700 .ssh && echo '%PUB%' >> .ssh/authorized_keys && chmod 600 .ssh/authorized_keys"

echo.
ssh -i "%KEY%" %OPTS% -o BatchMode=yes root@%AXUM_ENGINE% "echo ok" >nul 2>nul && (
  echo  GELUKT: deze pc is gekoppeld met de engine.
  echo  Start nu "Start AXUM Inzicht.bat" ^(opnieuw^).
) || (
  echo  Het koppelen is NIET gelukt. Klopte het wachtwoord?
  echo  Start dit bestand nog een keer om het opnieuw te proberen.
)
echo.
pause
