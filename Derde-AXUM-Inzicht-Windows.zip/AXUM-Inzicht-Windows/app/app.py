"""AXUM Inzicht - moderne, visuele weergave van de AXUM PostgreSQL-configuratie.

Fase 1: alleen lezen. De database wordt in read-only modus geopend; er wordt
niets geschreven. Wijzigingen die op het mengpaneel of via de oude webpagina
gebeuren komen live binnen via LISTEN/NOTIFY op het kanaal 'change'.

Configuratie via omgevingsvariabelen:
  AXUM_DB_HOST  (standaard 192.168.1.222, de engine; direct via het netwerk)
  AXUM_DB_PORT  (standaard 5432)
  AXUM_DB_USER  (standaard axum)
  AXUM_DB_NAME  (standaard axum)
  AXUM_DB_PASS  (standaard leeg)
"""
import asyncio
import json
import os
import select
import threading
import time
from pathlib import Path

try:
    import psycopg2
    import psycopg2.extras
    from fastapi import FastAPI, Request
except ImportError as _e:
    raise SystemExit(
        f"\nOntbrekende module: {_e}\n\n"
        "Start AXUM Inzicht niet via app.py, maar via:\n"
        "  - Windows: dubbelklik 'Start AXUM Inzicht.bat' in de hoofdmap (eerst het zip-bestand helemaal uitpakken)\n"
        "  - Linux:   ./run.sh\n")
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

DSN = dict(
    host=os.environ.get("AXUM_DB_HOST", "192.168.1.222"),
    port=int(os.environ.get("AXUM_DB_PORT", "5432")),
    user=os.environ.get("AXUM_DB_USER", "axum"),
    dbname=os.environ.get("AXUM_DB_NAME", "axum"),
    password=os.environ.get("AXUM_DB_PASS", ""),
    connect_timeout=5,
)

# MambaNet product-id's van software/systeem-nodes (man_id 1)
SYSTEM_PRODUCTS = {12: "Backplane", 13: "Gateway", 14: "Engine", 16: "Learner"}
BUSS_PAIRS = [f"{n}_{n + 1}" for n in range(1, 33, 2)]  # 1_2 .. 31_32

STATIC = Path(__file__).parent / "static"
app = FastAPI(title="AXUM Inzicht")
app.mount("/static", StaticFiles(directory=STATIC), name="static")


def connect():
    conn = psycopg2.connect(**DSN)
    conn.set_session(readonly=True, autocommit=True)
    return conn


import system  # noqa: E402  (systeem-pagina's: MambaNet, templates, functies, logs, versies)
system.init(connect)
app.include_router(system.router)
import mbnlive  # noqa: E402  (live MambaNet meelezen via SSH, alleen lezen)
app.include_router(mbnlive.router)


def rows(cur, sql, *args):
    cur.execute(sql, args)
    return [dict(r) for r in cur.fetchall()]


def load_state():
    conn = connect()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        nodes = rows(cur, """
            SELECT a.addr, a.name, (a.id).man AS man, (a.id).prod AS prod, (a.id).id AS uid,
                   a.active, a.firm_major, a.firstseen::text, a.lastseen::text,
                   (a.parent).man AS p_man, (a.parent).prod AS p_prod, (a.parent).id AS p_id,
                   s.slot_nr, COALESCE(s.input_ch_cnt, 0) AS inputs, COALESCE(s.output_ch_cnt, 0) AS outputs,
                   (SELECT COUNT(*) FROM templates t WHERE t.man_id = (a.id).man AND t.prod_id = (a.id).prod
                        AND t.firm_major = a.firm_major) AS objects,
                   (SELECT COUNT(*) FROM node_config n WHERE n.addr = a.addr AND n.firm_major = a.firm_major) AS config_cnt,
                   (SELECT COUNT(*) FROM defaults d WHERE d.addr = a.addr AND d.firm_major = a.firm_major) AS default_cnt
            FROM addresses a LEFT JOIN slot_config s ON s.addr = a.addr
            ORDER BY s.slot_nr NULLS LAST, a.addr""")
        for n in nodes:
            n["system"] = SYSTEM_PRODUCTS.get(n["prod"]) if n["man"] == 1 else None
            # rack-kaarten hangen aan de backplane (0001:000C); surfaces (fader-/knoppenpanelen) niet
            n["surface"] = not n["system"] and n["slot_nr"] is None and not (n["p_man"] == 1 and n["p_prod"] == 12)
            n["unique_id"] = "%04X:%04X:%04X" % (n["man"], n["prod"], n["uid"])

        sources = rows(cur, """SELECT number, pos, label, input1_addr, input1_sub_ch, input2_addr, input2_sub_ch,
                                      input_phantom, input_pad, input_gain, default_src_preset, related_dest
                               FROM src_config ORDER BY pos""")
        dests = rows(cur, """SELECT number, pos, label, output1_addr, output1_sub_ch, output2_addr, output2_sub_ch,
                                    level, source, mix_minus_source, routing
                             FROM dest_config ORDER BY pos""")
        matrix = rows(cur, "SELECT number, label, type, active FROM matrix_sources ORDER BY pos")
        busses = rows(cur, "SELECT * FROM buss_config ORDER BY number")
        monitor = rows(cur, "SELECT * FROM monitor_buss_config ORDER BY number")
        bus_cols = ", ".join(f"buss_{p}_assignment, buss_{p}_on_off, buss_{p}_level" for p in BUSS_PAIRS)
        modules = rows(cur, f"""SELECT number, console, source_a, source_b, source_c, source_d,
                                       source_e, source_f, source_g, source_h,
                                       mod_on_off, mod_level, mod_pan, eq_on_off, dyn_on_off, gain, {bus_cols}
                                FROM module_config ORDER BY number""")
        consoles = rows(cur, """SELECT number, name, location, contact, program_end_time::text,
                                       program_end_time_enable FROM console_config ORDER BY number""")
        glob = rows(cur, "SELECT samplerate, headroom, level_reserve, auto_momentary, startup_state, ext_clock_addr FROM global_config")
        talkback = rows(cur, "SELECT number, source FROM talkback_config ORDER BY number")
        changes = rows(cur, """SELECT change, arguments, timestamp::text AS ts FROM recent_changes
                               ORDER BY timestamp DESC LIMIT 50""")
        nodecfg = rows(cur, """
            SELECT n.addr, n.object, (n.func).type AS type, (n.func).seq AS seq, (n.func).func AS func,
                   n.label, t.description
            FROM node_config n JOIN addresses a ON a.addr = n.addr
            LEFT JOIN templates t ON t.man_id = (a.id).man AND t.prod_id = (a.id).prod
                 AND t.firm_major = n.firm_major AND t.number = n.object
            WHERE n.firm_major = a.firm_major ORDER BY n.addr, n.object""")
        predef = rows(cur, """
            SELECT p.cfg_name, p.man_id, p.prod_id, p.firm_major, p.object,
                   (p.func).type AS type, (p.func).seq AS seq, (p.func).func AS func, t.description
            FROM predefined_node_config p
            LEFT JOIN templates t ON t.man_id = p.man_id AND t.prod_id = p.prod_id
                 AND t.firm_major = p.firm_major AND t.number = p.object
            ORDER BY p.cfg_name, p.object""")
        funcnames = rows(cur, "SELECT (func).type AS type, (func).func AS func, name FROM functions")
        # officiële fader-curve van de engine: dB -> stand 0..1023
        cur.execute("SELECT db, position FROM db_to_position ORDER BY db")
        curve = [[r["db"], r["position"]] for r in cur.fetchall()]
        cur.execute("SELECT dsp_count()")
        dsp_count = list(cur.fetchone().values())[0]
    finally:
        conn.close()

    # modules: zet bus-kolommen om naar een compacte lijst
    for m in modules:
        m["busses"] = [
            {"on": m.pop(f"buss_{p}_on_off"), "assigned": m.pop(f"buss_{p}_assignment"),
             "level": m.pop(f"buss_{p}_level")}
            for p in BUSS_PAIRS
        ]
        m["sources"] = [m.pop(f"source_{c}") for c in "abcdefgh"]
    for mb in monitor:
        mb["busses"] = [mb.pop(f"buss_{p}") for p in BUSS_PAIRS]

    state = dict(nodes=nodes, sources=sources, dests=dests, matrix=matrix, busses=busses,
                 monitor=monitor, modules=modules, consoles=consoles,
                 global_config=glob[0] if glob else {}, talkback=talkback,
                 changes=changes, dsp_count=dsp_count, curve=curve, loaded_at=time.strftime("%H:%M:%S"))
    state["functions"] = analyse_functions(state, nodecfg, predef, funcnames)
    state["issues"] = find_issues(state)
    return state


# ---------- kaart-functies en import-offset analyse ----------
FUNC_TYPES = {0: "Module", 1: "Bus", 2: "Monitorbus", 3: "Console", 4: "Globaal", 5: "Bron", 6: "Bestemming"}
OFFSET_RANGE = range(-1300, 1301)


def simulate_import(entries, off, src_pos, dst_pos):
    """Exacte nabootsing van setpre() in Rack.pm (regel 686-734), inclusief de stille terugval.

    Geeft {object: (type, seq, func)} terug plus de lijst objecten waarvoor de
    offset niet klopte (terugval naar de eerste bron/bestemming of afgekapt)."""
    first_src = min(src_pos.values()) if src_pos else None
    first_dst = min(dst_pos.values()) if dst_pos else None
    out, bad = {}, []
    for e in entries:
        t, v = e["type"], e["seq"] + off
        wrong = False
        if t == 0:
            r = min(max(v, 0), 131); wrong = r != v
        elif t in (1, 2):
            r = min(max(v, 0), 19); wrong = r != v
        elif t == 3:
            r = min(max(v, 0), 3); wrong = r != v
        elif t in (5, 6):
            pos, first = (src_pos, first_src) if t == 5 else (dst_pos, first_dst)
            if v in pos:
                r = pos[v] - 1
            elif first is not None:          # BUG in Perl: stil naar de eerste bron/bestemming
                r = first - 1; wrong = True
            elif 1279 < v <= 1284:           # in Perl onbereikbaar zodra er bronnen bestaan
                r = v
                wrong = not (1279 < e["seq"] <= 1284)  # alleen 'goed' als het al een speciaal nummer was
            else:
                r = 0; wrong = True
        else:
            r = 0
        out[e["object"]] = (t, r, e["func"])
        if wrong:
            bad.append(e["object"])
    return out, bad


def ranges(nums):
    """[-4,-3,-2,5] -> '-4 t/m -2, 5'"""
    out, start, prev = [], None, None
    for n in nums:
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            out.append(str(start) if start == prev else f"{start} t/m {prev}"); start = prev = n
    if start is not None:
        out.append(str(start) if start == prev else f"{start} t/m {prev}")
    return ", ".join(out)


def analyse_functions(s, nodecfg, predef, funcnames):
    fname = {(f["type"], f["func"]): f["name"] for f in funcnames}
    src_by_nr = {x["number"]: x for x in s["sources"]}
    dst_by_nr = {x["number"]: x for x in s["dests"]}
    bus_by_nr = {x["number"]: x for x in s["busses"]}
    mon_by_nr = {x["number"]: x for x in s["monitor"]}
    src_pos = {x["pos"]: x["number"] for x in s["sources"]}
    dst_pos = {x["pos"]: x["number"] for x in s["dests"]}

    def target(t, seq):
        n = seq + 1
        if t == 5:
            return f"Bron {src_by_nr[n]['label']}" if n in src_by_nr else f"Bron #{n} (bestaat niet)"
        if t == 6:
            return f"Bestemming {dst_by_nr[n]['label']}" if n in dst_by_nr else f"Bestemming #{n} (bestaat niet)"
        if t == 1:
            return f"Bus {bus_by_nr[n]['label']}" if n in bus_by_nr else f"Bus {n}"
        if t == 2:
            return f"Monitorbus {mon_by_nr[n]['label']}" if n in mon_by_nr else f"Monitorbus {n}"
        if t == 0:
            return f"Module {n}"
        if t == 3:
            return f"Console {n}"
        return FUNC_TYPES.get(t, f"type {t}")

    def describe(t, seq, func):
        return dict(type=t, type_name=FUNC_TYPES.get(t, str(t)), seq=seq, func=func,
                    name=fname.get((t, func), f"functie {func}"), target=target(t, seq))

    cfg_by_product = {}
    for p in predef:
        key = (p["man_id"], p["prod_id"], p["firm_major"])
        cfg_by_product.setdefault(key, {}).setdefault(p["cfg_name"], []).append(p)
    cur_by_addr = {}
    for n in nodecfg:
        cur_by_addr.setdefault(n["addr"], []).append(n)

    result = []
    for node in s["nodes"]:
        cfgs = cfg_by_product.get((node["man"], node["prod"], node["firm_major"]), {})
        current_rows = cur_by_addr.get(node["addr"], [])
        if not current_rows and not cfgs:
            continue
        current = {r["object"]: (r["type"], r["seq"], r["func"]) for r in current_rows}
        imports = []
        for cfg_name, entries in cfgs.items():
            matched_ok, matched_bad, valid = [], [], []
            best_partial = None  # (aantal fout, |offset|, offset) als geen enkele offset volledig klopt
            for off in OFFSET_RANGE:
                sim, bad = simulate_import(entries, off, src_pos, dst_pos)
                if not bad:
                    valid.append(off)
                key = (len(bad), abs(off), off)
                if best_partial is None or key < best_partial:
                    best_partial = key
                if current and sim == current:
                    (matched_bad if bad else matched_ok).append(off)
            # voorgestelde offset: volledig geldig en zo dicht mogelijk bij 0, anders de minst slechte
            suggestion = min(valid, key=abs) if valid else best_partial[2]
            partial = not valid
            types = {e["type"] for e in entries} - {4}
            positions = sorted({e["seq"] for e in entries if e["type"] in (5, 6)})
            status = "ok" if matched_ok else "fout" if matched_bad else "geen"
            used = min(matched_ok or matched_bad, key=abs) if (matched_ok or matched_bad) else None
            missing = [k for k, pos in (("bronnen", src_pos), ("bestemmingen", dst_pos))
                       if not pos and any(e["type"] == (5 if k == "bronnen" else 6) for e in entries)]
            imp = dict(cfg_name=cfg_name, status=status, count=len(entries), missing=missing,
                       positions=positions, pos_kind=("bron" if types & {5, 6} == {5} else "bestemming"
                                                      if types & {5, 6} == {6} else "bron/bestemming"),
                       mixed=sorted(FUNC_TYPES.get(t, str(t)) for t in types) if len(types) > 1 else None,
                       matched_offset=used, valid=ranges(valid), suggestion=suggestion,
                       partial=partial, partial_bad=best_partial[0] if partial else 0)
            sim, _ = simulate_import(entries, suggestion, src_pos, dst_pos)
            imp["preview"] = {str(e["object"]): dict(describe(*sim[e["object"]]), description=e["description"])
                              for e in entries}
            if status == "fout":
                _, bad = simulate_import(entries, used, src_pos, dst_pos)
                imp["bad_objects"] = bad
            imports.append(imp)
        imports.sort(key=lambda i: {"fout": 0, "ok": 1, "geen": 2}[i["status"]])
        funcs = [dict(object=r["object"], description=r["description"], label=r["label"],
                      **describe(r["type"], r["seq"], r["func"])) for r in current_rows]
        # alle objecten die op hetzelfde doel uitkomen tellen (teken van terugval)
        result.append(dict(addr=node["addr"], name=node["name"], slot_nr=node["slot_nr"],
                           functions=funcs, imports=imports))
    return result


def find_issues(s):
    """Zoek inconsistenties die de oude webpagina verbergt."""
    issues = []
    by_addr = {n["addr"]: n for n in s["nodes"]}
    matrix = {m["number"]: m for m in s["matrix"]}

    def check_channel(kind, owner, addr, ch, direction):
        if not addr and not ch:
            issues.append(dict(level="warn", kind=kind, ref=owner["number"],
                               text=f"{kind} '{owner['label']}': {direction} niet gekoppeld"))
            return
        node = by_addr.get(addr)
        name = node["name"] if node else f"adres {addr}"
        if node is None:
            issues.append(dict(level="error", kind=kind, ref=owner["number"],
                               text=f"{kind} '{owner['label']}': {direction} wijst naar onbekend MambaNet-adres {addr}"))
        elif node["slot_nr"] is None:
            issues.append(dict(level="error", kind=kind, ref=owner["number"],
                               text=f"{kind} '{owner['label']}': {direction} wijst naar {name}, maar die zit in geen rack-slot"))
        elif not node["active"]:
            issues.append(dict(level="error", kind=kind, ref=owner["number"],
                               text=f"{kind} '{owner['label']}': {direction} wijst naar {name}, maar die node is offline"))
        else:
            cnt = node["inputs"] if direction.startswith("input") else node["outputs"]
            if ch > cnt:
                issues.append(dict(level="error", kind=kind, ref=owner["number"],
                                   text=f"{kind} '{owner['label']}': {direction} = {name} (slot {node['slot_nr']}) kanaal {ch}, "
                                        f"maar slot_config meldt maar {cnt} {'inputs' if direction.startswith('input') else 'outputs'}. "
                                        f"De oude pagina toont dit als 'Slot 0 ch 0'."))

    def check_pair(kind, owner, a1, c1, a2, c2, direction):
        # links en rechts samen controleren; identieke meldingen samenvoegen
        before = len(issues)
        check_channel(kind, owner, a1, c1, direction + " links")
        check_channel(kind, owner, a2, c2, direction + " rechts")
        new = issues[before:]
        if len(new) == 2 and a1 == a2:
            del issues[before:]
            new[0]["text"] = (new[0]["text"].replace(direction + " links", direction)
                              .replace(f"kanaal {c1},", f"kanaal {c1}/{c2},"))
            issues.append(new[0])

    for src in s["sources"]:
        check_pair("Bron", src, src["input1_addr"], src["input1_sub_ch"],
                   src["input2_addr"], src["input2_sub_ch"], "input")
    for d in s["dests"]:
        check_pair("Bestemming", d, d["output1_addr"], d["output1_sub_ch"],
                   d["output2_addr"], d["output2_sub_ch"], "output")
        if d["source"] and d["source"] not in matrix:
            issues.append(dict(level="error", kind="Bestemming", ref=d["number"],
                               text=f"Bestemming '{d['label']}': signaal {d['source']} bestaat niet"))
        elif d["source"] and not matrix[d["source"]]["active"]:
            issues.append(dict(level="warn", kind="Bestemming", ref=d["number"],
                               text=f"Bestemming '{d['label']}': signaal '{matrix[d['source']]['label']}' is niet actief"))

    for n in s["nodes"]:
        if n["system"]:
            continue
        if not n["active"]:
            issues.append(dict(level="warn", kind="Node", ref=n["addr"],
                               text=f"Node '{n['name']}' (adres {n['addr']:08X}, {n['unique_id']}) is offline, "
                                    f"laatst gezien {n['lastseen'][:16]}"))
        elif n["slot_nr"] is None and not n["surface"]:
            issues.append(dict(level="info", kind="Node", ref=n["addr"],
                               text=f"Node '{n['name']}' (adres {n['addr']:08X}) zit niet in een rack-slot "
                                    f"(surface-/externe node?)"))

    for nf in s.get("functions", []):
        for imp in nf["imports"]:
            if imp["status"] == "fout":
                pos = ", ".join(str(p) for p in imp["positions"])
                advice = (f"Er zijn geen {' en '.join(imp['missing'])}; maak die eerst aan." if imp["missing"] else
                          f"Beste offset: {imp['suggestion']} (geen offset klopt volledig, {imp['partial_bad']} "
                          f"objecten blijven fout)" if imp["partial"] else f"Juiste offset: {imp['suggestion']}")
                issues.append(dict(level="error", kind="Functies", ref=nf["addr"],
                                   text=f"Kaart '{nf['name']}': functies geïmporteerd uit '{imp['cfg_name']}' met offset "
                                        f"{imp['matched_offset']}. Daarmee bestaan {imp['pos_kind']}-posities {pos} niet, "
                                        f"dus de Perl-pagina heeft {len(imp.get('bad_objects', []))} objecten zonder "
                                        f"melding verkeerd gekoppeld. {advice}"))

    used = {sv for m in s["modules"] for sv in m["sources"]} | {d["source"] for d in s["dests"]}
    for src in s["sources"]:
        if src["number"] + 288 not in used:
            issues.append(dict(level="info", kind="Bron", ref=src["number"],
                               text=f"Bron '{src['label']}' wordt door geen enkele module of bestemming gebruikt"))
    return issues


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/state")
def api_state():
    return load_state()


# ---------- live updates via LISTEN/NOTIFY ----------
subscribers: set[asyncio.Queue] = set()
loop_ref: dict = {}


def listen_thread():
    while True:
        try:
            conn = psycopg2.connect(**DSN)
            conn.set_session(autocommit=True)
            cur = conn.cursor()
            cur.execute("LISTEN change")
            last = time.strftime("%Y-%m-%d %H:%M:%S")
            cur.execute("SELECT now()::text")
            last = cur.fetchone()[0]
            while True:
                if select.select([conn], [], [], 30) == ([], [], []):
                    continue
                conn.poll()
                if not conn.notifies:
                    continue
                conn.notifies.clear()
                cur.execute("""SELECT change, arguments, timestamp::text FROM recent_changes
                               WHERE timestamp > %s ORDER BY timestamp""", (last,))
                new = cur.fetchall()
                if new:
                    last = new[-1][2]
                msg = json.dumps([dict(change=c, arguments=a, ts=t) for c, a, t in new])
                loop = loop_ref.get("loop")
                if loop:
                    for q in list(subscribers):
                        loop.call_soon_threadsafe(q.put_nowait, msg)
        except Exception as e:  # verbinding weg: opnieuw proberen
            print("LISTEN-verbinding verbroken:", e)
            time.sleep(5)


@app.on_event("startup")
async def startup():
    loop_ref["loop"] = asyncio.get_running_loop()
    threading.Thread(target=listen_thread, daemon=True).start()


@app.get("/api/events")
async def events(request: Request):
    q: asyncio.Queue = asyncio.Queue()
    subscribers.add(q)

    async def gen():
        try:
            yield "event: hello\ndata: {}\n\n"
            while not await request.is_disconnected():
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=20)
                    yield f"event: change\ndata: {msg}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            subscribers.discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream")
