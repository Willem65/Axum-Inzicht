"""Live MambaNet meelezen (alleen lezen).

Faders en knoppen worden niet in Postgres opgeslagen: de surface stuurt ze via
MambaNet-over-UDP (poort 34848) naar axum-gateway op de engine. Dit module start,
zolang er minstens één browser meekijkt, via SSH een klein Perl-script op de engine
dat die UDP-pakketten meeleest en als hex-regels teruggeeft. Er wordt niets op de
engine geïnstalleerd of weggeschreven; het script stopt zodra de verbinding wegvalt.

Instellingen (omgevingsvariabelen):
  AXUM_ENGINE    IP-adres van de engine            (standaard 192.168.1.222)
  AXUM_SSH_USER  SSH-gebruiker                     (standaard root)
  AXUM_SSH_KEY   SSH-sleutel                       (standaard ~/.ssh/id_rsa_axum)
"""
import asyncio
import json
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

router = APIRouter(prefix="/api/mbn")

ENGINE = os.environ.get("AXUM_ENGINE", "192.168.1.222")
SSH_USER = os.environ.get("AXUM_SSH_USER", "root")
SSH_KEY = os.path.expanduser(os.environ.get("AXUM_SSH_KEY", "~/.ssh/id_rsa_axum"))
PORT = 34848
SSH_OPTS = ["-i", SSH_KEY, "-o", "BatchMode=yes", "-o", "ConnectTimeout=8",
            "-o", "StrictHostKeyChecking=accept-new",       # eerste keer op een nieuwe pc: engine-sleutel opslaan
            "-o", "HostKeyAlgorithms=+ssh-rsa",              # de engine heeft een oude SSH-server
            "-o", "PubkeyAcceptedKeyTypes=+ssh-rsa"]         # oude optienaam: werkt ook met OpenSSH 8.1 (Windows)

# Perl op de engine: raw socket op eth0, alleen UDP-poort 34848, schrijft nooit naar schijf.
# Elke 5 s een hartslag-regel, zodat het script stopt (SIGPIPE) als de SSH-verbinding weg is.
PERL = r"""
use strict; use Socket; use Time::HiRes qw(time);
socket(my $s, 17, 3, 0x0300) or die "socket: $!";
$| = 1; my $last = time;
my $rin = ''; vec($rin, fileno($s), 1) = 1;
while (1) {
  if (time - $last > 5) { print "hb\n"; $last = time; }
  next unless select(my $r = $rin, undef, undef, 1);
  my $p; recv($s, $p, 2000, 0) or next;
  next if length($p) < 42 || unpack("n", substr($p, 12, 2)) != 0x0800;
  my $ihl = (ord(substr($p, 14, 1)) & 15) * 4;
  next if ord(substr($p, 23, 1)) != 17;
  my ($sp, $dp) = unpack("nn", substr($p, 14 + $ihl, 4));
  next unless $sp == 34848 || $dp == 34848;
  printf "%.3f %s %s\n", time, ($dp == 34848 ? "in" : "out"), unpack("H*", substr($p, 14 + $ihl + 8));
}
"""

ACTIONS = {0: "get_info", 1: "info_response", 32: "get_sensor", 33: "sensor_response", 34: "sensor_changed",
           64: "get_actuator", 65: "actuator_response", 66: "set_actuator"}


def unpack7(enc):
    """MambaNet-data: 7-bits bytes, LSB eerst aaneengeschoven -> 8-bits bytes."""
    v = n = 0
    out = []
    for b in enc:
        v |= (b & 0x7F) << n
        n += 7
        while n >= 8:
            out.append(v & 0xFF)
            v >>= 8
            n -= 8
    return bytes(out)


def parse(p):
    if len(p) < 16 or p[0] & 0x80 == 0:
        return None
    to = ((p[0] & 0x0F) << 28) | (p[1] << 21) | (p[2] << 14) | (p[3] << 7) | p[4]
    fr = (p[5] << 21) | (p[6] << 14) | (p[7] << 7) | p[8]
    mtype = (p[12] << 7) | p[13]
    d = unpack7(p[15:15 + p[14]])
    if mtype != 1 or len(d) < 5:
        return None
    obj, act, dt, size = int.from_bytes(d[:2], "big"), d[2], d[3], d[4]
    raw = d[5:5 + size]
    if dt in (1, 3):
        val = int.from_bytes(raw, "big")
    elif dt == 2:
        val = int.from_bytes(raw, "big", signed=True)
    elif dt == 4:
        val = raw.split(b"\0")[0].decode("latin1")
    elif dt == 5 and len(raw) in (2, 4):          # float: 2 bytes = half precision (meters in dB)
        import struct
        val = round(struct.unpack(">e" if len(raw) == 2 else ">f", raw)[0], 1)
    else:
        val = raw.hex()
    return dict(to=to, fr=fr, obj=obj, act=ACTIONS.get(act, act), dt=dt, val=val)


class Listener:
    def __init__(self):
        self.subs: set[asyncio.Queue] = set()
        self.loop = None
        self.proc = None
        self.lock = threading.Lock()
        self.state = {}      # (node, obj) -> laatste waarde, voor nieuwe kijkers
        self.status = "uit"
        self.thread = None

    def available(self):
        if not shutil.which("ssh"):
            return "ssh niet gevonden"
        if not Path(SSH_KEY).exists():
            return f"SSH-sleutel {SSH_KEY} niet gevonden"
        return None

    def broadcast(self, msg):
        data = json.dumps(msg)
        for q in list(self.subs):
            self.loop.call_soon_threadsafe(q.put_nowait, data)

    def run(self):
        while True:
            with self.lock:
                if not self.subs:
                    self.thread = None
                    self.status = "uit"
                    return
            self.status = "verbinden"
            self.broadcast(dict(kind="status", status=self.status))
            cmd = ["ssh", *SSH_OPTS, "-o", "ServerAliveInterval=10", f"{SSH_USER}@{ENGINE}", "perl -"]
            try:
                self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                             stderr=subprocess.PIPE, text=True, bufsize=1)
                self.proc.stdin.write(PERL)
                self.proc.stdin.close()
                for line in self.proc.stdout:
                    if not self.subs:
                        break
                    if self.status != "live":
                        self.status = "live"
                        self.broadcast(dict(kind="status", status="live"))
                    parts = line.split()
                    if len(parts) != 3:
                        continue
                    m = parse(bytes.fromhex(parts[2]))
                    if not m:
                        continue
                    # node = de surface/kaart: bij 'in' de afzender, bij 'out' de ontvanger
                    m.update(kind="mbn", t=float(parts[0]), dir=parts[1],
                             node=m["fr"] if parts[1] == "in" else m["to"])
                    if m["act"] in ("sensor_changed", "set_actuator", "sensor_response", "actuator_response"):
                        self.state[(m["node"], m["obj"], m["act"] == "set_actuator")] = m
                    self.broadcast(m)
                err = self.proc.stderr.read().strip() if self.proc.poll() is not None else ""
            except Exception as e:  # noqa: BLE001
                err = str(e)
            finally:
                self.stop_proc()
            if self.subs:
                self.status = "fout"
                self.broadcast(dict(kind="status", status="fout", error=err[-300:] or "verbinding verbroken"))
                time.sleep(5)

    def stop_proc(self):
        p, self.proc = self.proc, None
        if p and p.poll() is None:
            p.terminate()
            try:
                p.wait(3)
            except subprocess.TimeoutExpired:
                p.kill()

    def subscribe(self, q):
        with self.lock:
            self.subs.add(q)
            if self.thread is None:
                self.status = "start"
                self.thread = threading.Thread(target=self.run, daemon=True)
                self.thread.start()

    def unsubscribe(self, q):
        with self.lock:
            self.subs.discard(q)
            if not self.subs:
                self.stop_proc()


L = Listener()


@router.get("/events")
async def events(request: Request):
    L.loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue()
    problem = L.available()

    async def gen():
        if problem:
            yield f"data: {json.dumps(dict(kind='status', status='fout', error=problem))}\n\n"
            return
        L.subscribe(q)
        try:
            yield f"data: {json.dumps(dict(kind='status', status=L.status))}\n\n"
            for m in list(L.state.values()):          # laatst bekende waardes
                yield f"data: {json.dumps(dict(m, replay=True))}\n\n"
            while not await request.is_disconnected():
                try:
                    yield f"data: {await asyncio.wait_for(q.get(), timeout=15)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            L.unsubscribe(q)

    return StreamingResponse(gen(), media_type="text/event-stream")


# ---------- startstand uit /var/lib/axum/.backup ----------
# axum-engine schrijft elke 30 s (als er iets veranderd is) zijn geheugen weg naar dit bestand.
# Indeling empirisch bepaald (axum-engine op deze engine, 2026-11-19):
#   128 module-blokken van 4004 bytes; module 1 niveau (float, dB) op offset 374280
#   actuele bron (matrix-nummer, int) op niveau-348
#   16 bussen à 32 bytes vanaf niveau+24; 'aan' = byte +8 in elke bus
#   1280 bronnen à 148 bytes vanaf 168 (label); Start = byte +133
#   16 monitorbussen à 108 bytes vanaf 2450600 (label); bus-keuze = 16 bytes vanaf +56;
#   phones-niveau (float dB) op +80, speaker-niveau op +84
BK_LEVEL0, BK_STRIDE, BK_MODULES = 374280, 4004, 128
BK_SRC0, BK_SRC_STRIDE, BK_SOURCES = 168, 148, 1280
BK_MON0, BK_MON_STRIDE = 2450600, 108
_bk_cache = {"t": 0, "data": None}


def read_backup():
    import struct
    if time.time() - _bk_cache["t"] < 10 and _bk_cache["data"]:
        return _bk_cache["data"]
    problem = L.available()
    if problem:
        return dict(error=problem)
    cmd = ["ssh", *SSH_OPTS, f"{SSH_USER}@{ENGINE}",
           "stat -c %Y /var/lib/axum/.backup && cat /var/lib/axum/.backup"]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=40)
    except subprocess.TimeoutExpired:
        return dict(error="SSH naar de engine duurde te lang")
    if r.returncode != 0:
        return dict(error=r.stderr.decode(errors="replace")[-300:] or "SSH mislukt")
    nl = r.stdout.index(b"\n")
    mtime, b = int(r.stdout[:nl]), r.stdout[nl + 1:]
    if len(b) < BK_LEVEL0 + BK_STRIDE * BK_MODULES:
        return dict(error=f".backup is kleiner dan verwacht ({len(b)} bytes)")
    mods = []
    for m in range(BK_MODULES):
        o = BK_LEVEL0 + m * BK_STRIDE
        level = struct.unpack_from("<f", b, o)[0]
        src = struct.unpack_from("<i", b, o - 348)[0]
        if not (-141 <= level <= 20) or not (0 <= src < 2000):
            return dict(error=f"onbekende indeling van .backup (module {m + 1}: niveau {level}, bron {src}); "
                              "mogelijk een andere versie van axum-engine")
        mods.append(dict(number=m + 1, level=round(level, 1), source=src,
                         bus_on=[bool(b[o + 24 + 32 * i + 8]) for i in range(16)]))
    # bronnen: 1280 records van 148 bytes vanaf 168 (label 32 bytes); +133 = Start aan/uit
    sources = []
    for k in range(BK_SOURCES):
        o = BK_SRC0 + k * BK_SRC_STRIDE
        lab = b[o:o + 32].split(b"\0")[0].decode("latin1")
        if lab or b[o + 133]:
            sources.append(dict(number=k + 1, label=lab, start=bool(b[o + 133])))
    # monitorbussen: 16 records van 108 bytes vanaf 2450600 (label 32 bytes); +56 = 16 bytes bus-keuze
    monitors = []
    for k in range(16):
        o = BK_MON0 + k * BK_MON_STRIDE
        lab = b[o:o + 32].split(b"\0")[0].decode("latin1")
        if not lab.isprintable():
            return dict(error=f"onbekende indeling van .backup (monitorbus {k + 1})")
        phones, speaker = struct.unpack_from("<ff", b, o + 80)      # niveaus in dB
        monitors.append(dict(number=k + 1, label=lab, bus=[bool(x) for x in b[o + 56:o + 72]],
                             phones=round(phones, 1), speaker=round(speaker, 1)))
    data = dict(mtime=mtime, modules=mods, sources=sources, monitors=monitors)
    _bk_cache.update(t=time.time(), data=data)
    return data


@router.get("/backup")
def backup():
    return read_backup()
