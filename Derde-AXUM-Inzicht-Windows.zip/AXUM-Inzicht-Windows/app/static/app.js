// AXUM Inzicht - frontend (alleen lezen)
let S = null;            // laatste state van /api/state
let consoleSel = 0;   // 0 = alle consoles
const $ = (id) => document.getElementById(id);
const esc = (v) => String(v ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const hex = (n) => n.toString(16).toUpperCase().padStart(8, "0");
const db = (v) => (v <= -138 ? "-∞" : (v > 0 ? "+" : "") + v.toFixed(1)) + " dB";

// ---------- tabs ----------
document.querySelectorAll("#tabs button").forEach((b) =>
  b.addEventListener("click", () => {
    document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("active", x === b));
    document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + b.dataset.view));
    if (b.dataset.view === "flow") requestAnimationFrame(drawFlowLines);
    if (b.dataset.view === "surface") requestAnimationFrame(drawSurfLines);
    if (b.dataset.view === "system") showSys(sysTab);
  }));
$("panel-close").onclick = () => $("panel").classList.add("hidden");

// ---------- data ----------
async function load() {
  const r = await fetch("/api/state");
  if (!r.ok) { $("loaded").textContent = "fout bij laden: " + r.status; return; }
  S = await r.json();
  try {
    index();
    renderAll();
  } catch (e) {
    console.error(e);
    $("loaded").innerHTML = `<span style="color:var(--bad)">JS-fout: ${esc(e.message)} (${esc((e.stack || "").split("\n")[1] || "")})</span>`;
  }
}

// afgeleide opzoektabellen
let byAddr, matrix, srcUse, chanUse;
function index() {
  byAddr = Object.fromEntries(S.nodes.map((n) => [n.addr, n]));
  matrix = Object.fromEntries(S.matrix.map((m) => [m.number, m]));
  // welke modules / bestemmingen gebruiken een matrix-bron
  srcUse = {};
  const add = (k, v) => (srcUse[k] ||= []).push(v);
  S.modules.forEach((m) => new Set(m.sources).forEach((s) => s > 0 && add(s, { type: "module", m })));
  S.dests.forEach((d) => d.source > 0 && add(d.source, { type: "dest", d }));
  // welke kaartkanalen gebruikt worden: "addr:ch" -> [{dir, owner, side}]
  chanUse = {};
  const use = (addr, ch, v) => addr && ch && (chanUse[addr + ":" + ch] ||= []).push(v);
  S.sources.forEach((s) => { use(s.input1_addr, s.input1_sub_ch, { dir: "in", s, side: "L" }); use(s.input2_addr, s.input2_sub_ch, { dir: "in", s, side: "R" }); });
  S.dests.forEach((d) => { use(d.output1_addr, d.output1_sub_ch, { dir: "out", d, side: "L" }); use(d.output2_addr, d.output2_sub_ch, { dir: "out", d, side: "R" }); });
}
const label = (num) => (num === 0 ? "none" : matrix[num]?.label ?? "#" + num);
const cardKind = (n) => (n.inputs > 0 ? "in" : n.outputs > 0 ? "out" : "other");
const issuesFor = (kind, ref) => S.issues.filter((i) => i.kind === kind && i.ref === ref && i.level !== "info");

function renderAll() {
  funcAllCache = null;
  const g = S.global_config;
  const clock = g.ext_clock_addr ? (byAddr[g.ext_clock_addr]?.name ?? hex(g.ext_clock_addr)) : "intern";
  $("global").innerHTML = g.samplerate ? esc(`${(g.samplerate / 1000).toFixed(1)} kHz · headroom ${g.headroom} dB · klok: ${clock} · ${S.dsp_count} DSP`)
    : `<span style="color:var(--warn)">global_config is leeg</span> · ${S.dsp_count} DSP`;
  $("loaded").textContent = "geladen " + S.loaded_at;
  const bad = S.issues.filter((i) => i.level === "error").length;
  $("issue-count").textContent = bad || "";
  renderRack(); renderFlow(); renderFunctions(); renderModules(); renderBusses(); renderIssues(); renderLog(); renderSurface();
}

// ---------- rack ----------
function renderRack() {
  const slotted = S.nodes.filter((n) => n.slot_nr != null);
  // kaartslots 1 .. ENGINE_SLOT-1, daarna de (brede) engine in ENGINE_SLOT
  const nSlots = Math.max(ENGINE_SLOT - 1, ...slotted.map((n) => n.slot_nr));
  const rack = $("rack");
  const engine = S.nodes.find((n) => n.system === "Engine");
  rack.style.setProperty("--slots", nSlots + ENGINE_WIDTH);
  rack.innerHTML = '<div class="ear l"><i></i><i></i></div><div class="rail"></div>';
  for (let i = 1; i <= nSlots; i++) {
    const n = slotted.find((x) => x.slot_nr === i);
    const el = document.createElement("div");
    if (!n) { el.className = "slot"; el.textContent = i; rack.append(el); continue; }
    // brede kaarten (bijv. voeding) beslaan fysiek meerdere slots
    let w = 1;
    while (w < cardWidth(n) && i + w <= nSlots && !slotted.some((x) => x.slot_nr === i + w)) w++;
    if (w > 1) {
      el.style.gridColumn = `span ${w}`;
      i += w - 1;
    }
    // kanalen: aantal volgens slot_config, maar ook kanalen die bronnen/bestemmingen gebruiken
    const used = Object.keys(chanUse).filter((k) => +k.split(":")[0] === n.addr).map((k) => +k.split(":")[1]);
    const count = Math.max(n.inputs, n.outputs, ...used, 0);
    const leds = [];
    for (let c = 1; c <= Math.min(count, 32); c++) {
      const u = chanUse[n.addr + ":" + c];
      const max = Math.max(n.inputs, n.outputs);
      leds.push(`<span class="led ${u ? (c > max ? "broken" : "used") : ""}" title="kanaal ${c}${u ? " → " + u.map((x) => esc((x.s || x.d).label)).join(", ") : ""}"></span>`);
    }
    const hasProblem = !n.active || issuesForNode(n).length;
    el.className = `slot card ${cardKind(n)} ${hasProblem ? "bad" : ""}`;
    el.innerHTML = `<span class="nr">${n.slot_nr}${w > 1 ? "–" + (n.slot_nr + w - 1) : ""}</span><span class="name">${esc(n.name)}</span>
      <span class="leds">${leds.join("")}</span><span class="addr">${hex(n.addr).slice(-4)}</span>`;
    el.title = `${n.name}\nadres ${hex(n.addr)}\n${n.inputs} in / ${n.outputs} uit`;
    el.onclick = () => showNode(n);
    rack.append(el);
  }
  // de engine zit fysiek altijd helemaal rechts in het rack (slot ENGINE_SLOT)
  if (!engine) {
    rack.insertAdjacentHTML("beforeend", `<div class="slot" style="grid-column: span ${ENGINE_WIDTH}">${ENGINE_SLOT}</div>`);
  } else {
    const el = document.createElement("div");
    el.className = `slot card engine ${engine.active ? "" : "bad"}`;
    el.style.gridColumn = `span ${ENGINE_WIDTH}`;
    el.innerHTML = `<span class="nr">${ENGINE_SLOT}</span><span class="name">${esc(engine.name)}</span>
      <span class="dot ${engine.active ? "on" : "off"}"></span>
      <span class="addr">${hex(engine.addr).slice(-4)}</span>`;
    el.title = `${engine.name}\nadres ${hex(engine.addr)}\n${S.dsp_count} DSP${S.global_config.samplerate ? " · " + (S.global_config.samplerate / 1000).toFixed(1) + " kHz" : ""}`;
    el.onclick = () => showNode(engine);
    rack.append(el);
  }
  rack.insertAdjacentHTML("beforeend", '<div class="rail b"></div><div class="ear r"><i></i><i></i></div>');
  $("other-nodes").innerHTML = "";
  S.nodes.filter((n) => n.slot_nr == null && n !== engine).forEach((n) => {
    const el = document.createElement("div");
    el.className = "node";
    el.innerHTML = `<div><span class="dot ${n.active ? "on" : "off"}"></span> <b>${esc(n.name)}</b><br>
      <small>${n.system ? "systeem: " + n.system : n.surface ? "surface" : "niet in rack"} · ${hex(n.addr)}</small></div>
      <small>${n.objects} obj.<br>${n.config_cnt} cfg</small>`;
    el.onclick = () => showNode(n);
    $("other-nodes").append(el);
  });
  $("consoles").innerHTML = S.consoles.map((c) => `<div class="console"><b>Console ${c.number}: ${esc(c.name)}</b><br>
    <small>${esc(c.location)} · ${esc(c.contact)} · ${S.modules.filter((m) => m.console === c.number).length} modules</small></div>`).join("");
}
// fysieke breedte in slots per kaarttype ("man:prod"); standaard 1
const CARD_WIDTH = {
  "1:22": 3,   // Rack-PWR (voeding) beslaat 3 slots (1–3)
};
const cardWidth = (n) => CARD_WIDTH[`${n.man}:${n.prod}`] || 1;
const RACK_SLOTS = 20;    // totaal aantal slots in het rack
const ENGINE_SLOT = 20;   // de engine zit in het laatste slot...
const ENGINE_WIDTH = 2;   // ...en is 2 keer zo breed als een normaal slot

function issuesForNode(n) {
  const bad = [];
  S.sources.forEach((s) => [[s.input1_addr, s.input1_sub_ch], [s.input2_addr, s.input2_sub_ch]].forEach(([a, c]) => a === n.addr && c > n.inputs && bad.push(s)));
  S.dests.forEach((d) => [[d.output1_addr, d.output1_sub_ch], [d.output2_addr, d.output2_sub_ch]].forEach(([a, c]) => a === n.addr && c > n.outputs && bad.push(d)));
  return bad;
}

// ---------- detailpaneel ----------
function showNode(n) {
  const chans = Object.entries(chanUse).filter(([k]) => +k.split(":")[0] === n.addr)
    .sort((a, b) => a[0].split(":")[1] - b[0].split(":")[1]);
  const max = Math.max(n.inputs, n.outputs);
  $("panel-body").innerHTML = `<h3>${esc(n.name)}</h3>
    <p><span class="dot ${n.active ? "on" : "off"}"></span> ${n.active ? "online" : "offline"}${n.system ? " · systeem-node (" + n.system + ")" : n.surface ? " · surface (bedieningspaneel)" : ""}</p>
    <dl>
      <dt>Slot</dt><dd>${n.slot_nr ?? "–"}</dd>
      <dt>MambaNet-adres</dt><dd><code>${hex(n.addr)}</code></dd>
      <dt>Unique ID</dt><dd><code>${n.unique_id}</code></dd>
      <dt>Firmware major</dt><dd>${n.firm_major}</dd>
      <dt>Inputs / outputs</dt><dd>${n.inputs} / ${n.outputs} <small>(slot_config)</small></dd>
      <dt>Objecten</dt><dd>${n.objects} (template)</dd>
      <dt>Geconfigureerd</dt><dd>${n.config_cnt} functies, ${n.default_cnt} defaults</dd>
      <dt>Eerst gezien</dt><dd>${n.firstseen.slice(0, 16)}</dd>
      <dt>Laatst gezien</dt><dd>${n.lastseen.slice(0, 16)}</dd>
    </dl>
    <h4>Gebruikte kanalen</h4>
    ${chans.length ? "<ul>" + chans.map(([k, us]) => {
      const c = +k.split(":")[1];
      return `<li ${c > max ? 'style="color:var(--bad)"' : ""}>kanaal ${c}: ${us.map((u) => (u.dir === "in" ? "bron " : "bestemming ") + "<b>" + esc((u.s || u.d).label) + "</b> (" + u.side + ")").join(", ")}
        ${c > max ? "<br><small>buiten het aantal kanalen in slot_config (" + max + ")</small>" : ""}</li>`;
    }).join("") + "</ul>" : '<p class="empty">Geen bronnen of bestemmingen gekoppeld.</p>'}`;
  $("panel").classList.remove("hidden");
}
function showSource(s) {
  const uses = srcUse[s.number + 288] || [];
  $("panel-body").innerHTML = `<h3>Bron: ${esc(s.label)}</h3>
    <dl><dt>Nummer</dt><dd>${s.number} <small>(matrix ${s.number + 288})</small></dd>
      <dt>Input L</dt><dd>${chanText(s.input1_addr, s.input1_sub_ch)}</dd>
      <dt>Input R</dt><dd>${chanText(s.input2_addr, s.input2_sub_ch)}</dd>
      <dt>Gain</dt><dd>${s.input_gain} dB${s.input_phantom ? " · phantom" : ""}${s.input_pad ? " · pad" : ""}</dd></dl>
    <h4>Gebruikt door</h4>${uses.length ? "<ul>" + uses.map((u) => u.type === "module"
      ? `<li>Module ${u.m.number} (console ${u.m.console})</li>` : `<li>Bestemming <b>${esc(u.d.label)}</b></li>`).join("") + "</ul>"
      : '<p class="empty">Nergens gebruikt.</p>'}
    ${issueList(issuesFor("Bron", s.number))}`;
  $("panel").classList.remove("hidden");
}
function showDest(d) {
  $("panel-body").innerHTML = `<h3>Bestemming: ${esc(d.label)}</h3>
    <dl><dt>Nummer</dt><dd>${d.number}</dd>
      <dt>Output L</dt><dd>${chanText(d.output1_addr, d.output1_sub_ch)}</dd>
      <dt>Output R</dt><dd>${chanText(d.output2_addr, d.output2_sub_ch)}</dd>
      <dt>Signaal</dt><dd>${esc(label(d.source))} <small>(${matrix[d.source]?.type ?? "-"})</small></dd>
      <dt>Niveau</dt><dd>${db(d.level)}</dd>
      <dt>N-1 van</dt><dd>${esc(label(d.mix_minus_source))}</dd>
      <dt>Routing</dt><dd>${["stereo", "links", "rechts", "mono"][d.routing] ?? d.routing}</dd></dl>
    ${issueList(issuesFor("Bestemming", d.number))}`;
  $("panel").classList.remove("hidden");
}
function chanText(addr, ch) {
  if (!addr && !ch) return '<span class="empty">niet gekoppeld</span>';
  const n = byAddr[addr];
  return n ? `${esc(n.name)} · slot ${n.slot_nr ?? "–"} · kanaal ${ch}` : `onbekend adres ${hex(addr)} · kanaal ${ch}`;
}
const issueList = (list) => list.length ? `<h4>Problemen</h4>` + list.map(issueHTML).join("") : "";
const issueHTML = (i) => `<div class="issue ${i.level}"><span class="lv">${{ error: "fout", warn: "let op", info: "info" }[i.level]}</span><span>${esc(i.text)}</span></div>`;

// ---------- signaalpad ----------
let flowEdges = [];
const MOD_COUNT = 32;   // de AXUM heeft altijd 32 modules
function renderFlow() {
  const box = (id, cls, title, sub, onclick) => ({ id, cls, title, sub, onclick });
  // kolommen: 0 kaart-in · 1 bronnen · 2 modules · 3 bussen · 4 bestemmingen · 5 kaart-uit
  const cols = [[], [], [], [], [], []];
  flowEdges = [];
  const seen = new Set();
  const once = (col, b) => { if (!seen.has(b.id)) { seen.add(b.id); cols[col].push(b); } };
  const chanBox = (dir, addr, c1, c2) => {
    const n = byAddr[addr];
    const max = n ? (dir === "in" ? n.inputs : n.outputs) : 0;
    const bad = !n || !n.active || n.slot_nr == null || c1 > max || c2 > max;
    const id = `${dir}-${addr}-${c1}-${c2}`;
    once(dir === "in" ? 0 : 5, box(id, (dir === "in" ? "in" : "out") + (bad ? " bad" : ""),
      n ? `${esc(n.name)}` : "adres " + hex(addr || 0),
      `slot ${n?.slot_nr ?? "–"} · kanaal ${c1}${c2 !== c1 ? "/" + c2 : ""}`, () => n && showNode(n)));
    return [id, bad];
  };
  S.sources.forEach((s) => {
    const sid = "src-" + s.number;
    once(1, box(sid, issuesFor("Bron", s.number).length ? "bad" : "", esc(s.label), `bron ${s.number}`, () => showSource(s)));
    if (s.input1_addr || s.input1_sub_ch) {
      const [cid, bad] = chanBox("in", s.input1_addr, s.input1_sub_ch, s.input2_sub_ch);
      flowEdges.push([cid, sid, bad]);
    }
    S.modules.filter((m) => m.number <= MOD_COUNT && m.sources.includes(s.number + 288))
      .forEach((m) => flowEdges.push([sid, "mod-" + m.number, false]));
  });
  // altijd alle 32 modules (per DSP-kaart), ongebruikte modules grijs
  const usedMods = new Set();
  S.modules.filter((m) => m.number <= MOD_COUNT).forEach((m) => {
    const used = m.sources.some((x) => x > 288);
    if (used) usedMods.add(m.number);
    const srcA = m.sources.find((x) => x > 0);
    once(2, box("mod-" + m.number, used ? "mod" : "mod dim", `Module ${m.number}`,
      `console ${m.console}${srcA ? " · " + label(srcA) : ""}`, null));
  });
  // alle bussen apart, met lijnen van de modules die er (met een bron) aan toegewezen zijn
  S.busses.forEach((b) => {
    const bid = "bus-" + b.number;
    once(3, box(bid, "bus", esc(b.label), `bus ${b.number * 2 - 1}/${b.number * 2} · console ${b.console}`, null));
    S.modules.filter((m) => usedMods.has(m.number) && m.busses[b.number - 1]?.assigned)
      .forEach((m) => flowEdges.push(["mod-" + m.number, bid, false]));
  });
  S.dests.forEach((d) => {
    const did = "dst-" + d.number;
    once(4, box(did, issuesFor("Bestemming", d.number).length ? "bad" : "", esc(d.label), `bestemming ${d.number}`, () => showDest(d)));
    const t = matrix[d.source]?.type;
    if (t === "source") flowEdges.push(["src-" + (d.source - 288), did, false]);
    else if (d.source > 0) {
      const bid = "bus-" + d.source;
      once(3, box(bid, "bus" + (matrix[d.source]?.active === false ? " dim" : ""), esc(label(d.source)), t, null));
      flowEdges.push([bid, did, false]);
    }
    if (d.output1_addr || d.output1_sub_ch) {
      const [cid, bad] = chanBox("out", d.output1_addr, d.output1_sub_ch, d.output2_sub_ch);
      flowEdges.push([did, cid, bad]);
    }
  });
  const heads = ["Kaart-inputs (fysiek)", "Bronnen", `Modules (${MOD_COUNT})`, "Bussen", "Bestemmingen", "Kaart-outputs (fysiek)"];
  const flow = $("flow");
  flow.innerHTML = '<svg id="flow-svg"></svg>' + cols.map((c, i) =>
    `<div class="col"><h3>${heads[i]}</h3>${c.map((b) => `<div class="fbox ${b.cls}" id="${b.id}"><b>${b.title}</b><small>${esc(b.sub)}</small></div>`).join("") || '<span class="empty">–</span>'}</div>`).join("");
  cols.flat().forEach((b) => {
    const el = $(b.id);
    if (b.onclick) el.onclick = b.onclick;
    el.onmouseenter = () => highlight(b.id, true);
    el.onmouseleave = () => highlight(b.id, false);
  });
  requestAnimationFrame(drawFlowLines);
}
function drawFlowLines() {
  const svg = $("flow-svg"); if (!svg) return;
  const base = $("flow").getBoundingClientRect();
  if (!base.width) return;
  svg.innerHTML = flowEdges.map(([a, b, bad], i) => {
    const ea = $(a), eb = $(b); if (!ea || !eb) return "";
    const ra = ea.getBoundingClientRect(), rb = eb.getBoundingClientRect();
    const x1 = ra.right - base.left, y1 = ra.top + ra.height / 2 - base.top;
    const x2 = rb.left - base.left, y2 = rb.top + rb.height / 2 - base.top;
    const dx = (x2 - x1) / 2;
    return `<path data-a="${a}" data-b="${b}" class="${bad ? "bad" : ""}" d="M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}"/>`;
  }).join("");
}
function highlight(id, on) {
  // markeer de hele keten links en rechts van dit blok
  const ids = new Set([id]);
  const walk = (cur, dirKey, otherKey) => flowEdges.forEach((e) => { if (e[dirKey] === cur && !ids.has(e[otherKey])) { ids.add(e[otherKey]); walk(e[otherKey], dirKey, otherKey); } });
  walk(id, 0, 1); walk(id, 1, 0);
  document.querySelectorAll("#flow-svg path").forEach((p) => p.classList.toggle("hl", on && ids.has(p.dataset.a) && ids.has(p.dataset.b)));
  ids.forEach((i) => $(i)?.classList.toggle("hl", on));
}
window.addEventListener("resize", () => requestAnimationFrame(drawFlowLines));

// ---------- kaart-functies / import-offset ----------
function renderFunctions() {
  const typeCls = (t) => ({ 0: "t-mod", 1: "t-bus", 2: "t-bus", 3: "t-con", 5: "t-src", 6: "t-dst" }[t] || "");
  const chip = (f) => `<span class="chip ${typeCls(f.type)}">${esc(f.target)}</span>`;
  $("functions").innerHTML = S.functions.map((n) => {
    const imps = n.imports.map((i) => {
      const pos = i.positions.length ? `posities ${i.positions.join(", ")}` : "";
      let head;
      const sign = (o) => (o > 0 ? "+" : "") + o;
      const advice = i.missing?.length
        ? `<span class="warnline">Er zijn op dit moment geen ${esc(i.missing.join(" en "))} in de database.</span>
           <small>Maak eerst de ${esc(i.missing.join(" en "))} aan; daarna kan de juiste offset berekend worden.</small>`
        : i.partial
        ? `Beste offset: <span class="big warnc">${sign(i.suggestion)}</span>
           <small>Geen offset klopt volledig: ${i.partial_bad} objecten blijven fout. Deze import bevat ${esc((i.mixed || []).join(" én "))},
           en de Perl-pagina past één offset op alles toe.</small>`
        : `Juiste offset: <span class="big">${sign(i.suggestion)}</span>`;
      if (i.status === "fout")
        head = `<div class="imp fout"><b>✗ Import "${esc(i.cfg_name)}" is uitgevoerd met offset ${sign(i.matched_offset)}</b>
          <p>Deze import gebruikt ${esc(i.pos_kind)}-${pos}. Met offset ${sign(i.matched_offset)} bestaan die posities niet,
          en dan koppelt de Perl-pagina ze <b>zonder melding</b> aan de eerste ${esc(i.pos_kind)}.
          ${i.bad_objects?.length ?? 0} objecten zijn zo verkeerd terechtgekomen (rood in de tabel).</p>
          <p class="fix">${advice}</p></div>`;
      else if (i.status === "ok")
        head = `<div class="imp ok"><b>✓ Komt overeen met import "${esc(i.cfg_name)}" offset ${sign(i.matched_offset)}</b>
          <small>${pos}</small></div>`;
      else
        head = `<div class="imp geen"><b>Import "${esc(i.cfg_name)}" (niet gebruikt)</b> <small>${i.count} functies${pos ? ", " + pos : ""}</small>
          <p class="fix">${advice}</p></div>`;
      return { i, head };
    });
    // vergelijkingstabel: huidig vs. voorbeeld met voorgestelde offset (van de eerste import met een voorstel)
    const best = (imps.find((x) => x.i.status === "fout") || imps.find((x) => x.i.status === "geen" && !n.functions.length))?.i;
    const bad = new Set(n.imports.flatMap((i) => i.bad_objects || []));
    const objects = [...new Set([...n.functions.map((f) => f.object), ...Object.keys(best?.preview || {}).map(Number)])].sort((a, b) => a - b);
    const cur = Object.fromEntries(n.functions.map((f) => [f.object, f]));
    const table = objects.length ? `<div class="scroll"><table class="ft">
      <tr><th>Object</th><th>Beschrijving</th><th>Functie</th><th>Nu gekoppeld aan</th>${best ? `<th>Met offset ${best.suggestion}</th>` : ""}</tr>
      ${objects.map((o) => {
        const f = cur[o], p = best?.preview?.[o];
        const desc = f?.description ?? p?.description ?? "";
        return `<tr class="${bad.has(o) ? "badrow" : ""}"><td><code>${o}</code></td><td>${esc(desc)}</td>
          <td>${esc(f?.name ?? p?.name ?? "")}</td><td>${f ? chip(f) : '<span class="empty">–</span>'}</td>
          ${best ? `<td>${p ? chip(p) : ""}</td>` : ""}</tr>`;
      }).join("")}</table></div>` : '<p class="empty">Nog geen functies gekoppeld.</p>';
    return `<div class="fnode"><h3>${esc(n.name)} <small>${n.slot_nr ? "slot " + n.slot_nr : "niet in rack"} · ${hex(n.addr)} · ${n.functions.length} functies</small></h3>
      ${imps.map((x) => x.head).join("")}${table}</div>`;
  }).join("") || '<p class="empty">Geen kaarten met functies.</p>';
}

// ---------- modules ----------
function renderModules() {
  if (!sim) initSim();
  const maxMod = (S.dsp_count || 1) * MOD_COUNT;
  const all = S.modules.filter((m) => showAllModules || m.number <= maxMod);
  const consoles = [...new Set(all.map((m) => m.console))].sort();
  if (consoleSel && !consoles.includes(consoleSel)) consoleSel = 0;
  $("console-filter").innerHTML = `<button data-c="0" class="${consoleSel === 0 ? "active" : ""}">Alle consoles <small>(${all.length})</small></button>` + consoles.map((c) => `<button data-c="${c}" class="${c === consoleSel ? "active" : ""}">Console ${c} <small>(${all.filter((m) => m.console === c).length})</small></button>`).join("")
    + `<button id="mod-all" title="Met ${S.dsp_count} DSP-kaart(en) verwerkt de engine modules 1–${maxMod}">${showAllModules ? "alleen 1–" + maxMod : "toon alle 128"}</button>`
    + `<button id="mod-live" class="${liveOn ? "active" : ""}" title="PPM-meters en knoppen live via MambaNet">${liveOn ? "● Live aan" : "○ Live uit"}</button>`
    + `<span class="live-status ${liveStatus}">${liveOn ? esc({ live: "PPM live (alleen modules die op een surface staan)", verbinden: "verbinden…", start: "starten…", fout: "fout" }[liveStatus] ?? "") : ""}</span>`;
  $("console-filter").querySelectorAll("button[data-c]").forEach((b) => (b.onclick = () => { consoleSel = +b.dataset.c; renderModules(); }));
  $("mod-all").onclick = () => { showAllModules = !showAllModules; renderModules(); };
  $("mod-live").onclick = () => toggleLive();
  const busLbl = Object.fromEntries(S.busses.map((b) => [b.number, b.label]));
  funcAllCache ||= surfFuncAll();
  const metered = new Set(Object.entries(funcAllCache).filter(([a]) => byAddr[a]?.active).flatMap(([, o]) => Object.values(o))
    .filter((f) => f.type === 0 && /^Audio level/.test(f.name)).map((f) => f.seq + 1));
  const src = backup?.modules ? "stand van de engine (.backup)" : "database";
  $("modules").innerHTML = all.filter((m) => !consoleSel || m.console === consoleSel).map((m) => {
    const st = sim.mod[m.number] || {};
    const lvl = st.level ?? m.mod_level, cur = st.src ?? m.sources[0];
    const pos = Math.max(0, Math.min(1, (lvl + 60) / 70));  // -60..+10 dB
    const open = st.on !== false && lvl > -138;
    const mt = live.meter[m.number] || {};
    const meter = (side) => `<div class="vmeter" title="${metered.has(m.number) ? "PPM " + side : "geen meter: deze module staat op geen surface"}"><i data-meter="${m.number}${side}" style="height:${meterPct(mt[side])}%"></i></div>`;
    return `<div class="strip ${open ? "on" : ""} ${metered.has(m.number) ? "metered" : ""}">
      <div class="title">${m.number} <small>c${m.console}</small></div>
      <div class="cur" title="actuele bron (${src})">${cur > 0 ? esc(label(cur)) : '<span class="empty">geen bron</span>'}</div>
      <div class="src">${m.sources.map((x, i) => x ? `<b>${"ABCDEFGH"[i]}</b><span class="${x === cur ? "sel" : ""}" title="${esc(label(x))}">${esc(label(x))}</span>` : "").join("")}</div>
      <div class="bus">${m.busses.map((b, i) => { const on = st.bus ? st.bus[i] : b.on; return `<i class="${b.assigned ? "a" : ""} ${b.assigned && on ? "on" : ""}" title="${esc(busLbl[i + 1] ?? "bus " + (i + 1))}: ${b.assigned ? (on ? "aan" : "toegewezen, uit") : "niet toegewezen"}">${esc((busLbl[i + 1] ?? "").slice(0, 3))}</i>`; }).join("")}</div>
      <div class="fm">${meter("L")}${meter("R")}<div class="fader" title="module-niveau ${db(lvl)}"><i style="bottom:calc(${pos * 100}% - 5px)"></i></div></div>
      <div class="lvl">${db(lvl)}</div>
    </div>`;
  }).join("") || '<p class="empty">Geen modules voor deze console.</p>';
}

// ---------- bussen ----------
function renderBusses() {
  $("busses").innerHTML = S.busses.map((b) => {
    const pos = Math.max(0, Math.min(1, (b.level + 60) / 70));
    return `<div class="buscard"><span class="lbl">${esc(b.label)}</span> <small>bus ${b.number * 2 - 1}/${b.number * 2} · console ${b.console}</small>
      <small>${b.on_off ? "aan" : "uit"} · ${b.pre_on ? "pre" : "post"} · ${db(b.level)}${b.interlock ? " · interlock" : ""}${b.exclusive ? " · exclusive" : ""}${b.mono ? " · mono" : ""}</small>
      <div class="meter"><i style="width:${pos * 100}%"></i></div></div>`;
  }).join("");
  const dsp = S.dsp_count * 4;
  $("monitor").innerHTML = `<div class="scroll"><table class="mx"><tr><th class="l">Monitorbus</th><th>Console</th>${S.busses.map((b) => `<th class="v">${esc(b.label)}</th>`).join("")}<th>Dim</th></tr>
    ${S.monitor.map((m) => `<tr style="${m.number > dsp ? "opacity:.45" : ""}"><td class="l">${m.number}. ${esc(m.label)}</td><td>${m.console}</td>
      ${m.busses.map((v) => `<td class="${v ? "y" : ""}">${v ? "●" : ""}</td>`).join("")}<td>${db(m.dim_level)}</td></tr>`).join("")}
  </table></div><p class="empty">Grijs = niet actief (meer monitorbussen dan ${S.dsp_count} DSP-kaart(en) aankunnen).</p>`;
}

// ---------- problemen ----------
function renderIssues() {
  const order = { error: 0, warn: 1, info: 2 };
  const list = [...S.issues].sort((a, b) => order[a.level] - order[b.level]);
  $("issues").innerHTML = list.length ? list.map(issueHTML).join("") : '<p class="empty">Geen problemen gevonden.</p>';
}

// ---------- live log ----------
function renderLog(fresh = 0) {
  $("log").innerHTML = S.changes.map((c, i) => `<div class="${i < fresh ? "new" : ""}"><span>${c.ts.slice(11, 19)}</span>${esc(c.change)} <b>${esc(c.arguments)}</b></div>`).join("")
    || '<div class="empty">Geen wijzigingen in het afgelopen uur.</div>';
}

// ---------- systeem ----------
let sysTab = "mambanet";
const sysCache = {};
const yn = (v) => (v ? '<span class="yes">●</span>' : '<span class="no">○</span>');
const uid = (m, p, i) => [m, p, i].map((x) => x.toString(16).toUpperCase().padStart(4, "0")).join(":");
const LEVELS = ["Idle", "Onbekend", "Operator 1", "Operator 2", "Supervisor 1", "Supervisor 2"];
document.querySelectorAll("#sys-tabs button").forEach((b) => (b.onclick = () => showSys(b.dataset.sys)));

async function sysGet(path, fresh = false) {
  if (!fresh && sysCache[path]) return sysCache[path];
  const r = await fetch("/api/system/" + path);
  const data = await r.json();
  if (!r.ok) throw new Error(data.detail || r.status);
  return (sysCache[path] = data);
}

async function showSys(tab, fresh = false) {
  sysTab = tab;
  document.querySelectorAll("#sys-tabs button").forEach((x) => x.classList.toggle("active", x.dataset.sys === tab));
  const body = $("sys-body");
  body.innerHTML = '<p class="empty">laden…</p>';
  try { await SYS[tab](body, fresh); }
  catch (e) { body.innerHTML = `<div class="issue error"><span class="lv">fout</span><span>${esc(e.message)}</span></div>`; }
}

const table = (head, rows) => `<div class="scroll"><table class="st"><tr>${head.map((h) => `<th>${h}</th>`).join("")}</tr>${rows.join("")}</table></div>`;

const SYS = {
  async mambanet(body, fresh) {
    const d = await sysGet("mambanet", fresh);
    body.innerHTML = table(["", "Adres", "Unique ID", "Naam", "Slot", "Parent", "Engine", "Services", "User level", "Objecten", "Config", "Defaults", "Firmware", "Adresaanvragen", "Eerst gezien", "Laatst gezien"],
      d.map((n) => `<tr class="${n.active ? "" : "inactive"}"><td><span class="dot ${n.active ? "on" : "off"}"></span></td>
        <td><code>${hex(n.addr)}</code></td><td><code>${uid(n.man, n.prod, n.uid)}</code></td><td><b>${esc(n.name)}</b></td>
        <td>${n.slot_nr ?? "–"}</td><td>${esc(n.parent_name ?? uid(n.p_man, n.p_prod, n.p_id))}</td><td><code>${hex(n.engine_addr)}</code></td>
        <td>${n.services}</td><td>${n.user_level_from_console ? "console " + n.user_level_from_console : "–"}</td>
        <td>${n.objects}</td><td>${n.config_cnt}</td><td>${n.default_cnt}</td><td>${n.firm_major}</td><td>${n.addr_requests}</td>
        <td>${n.firstseen.slice(0, 16)}</td><td>${n.lastseen.slice(0, 16)}</td></tr>`));
  },
  async register(body, fresh) {
    const d = (await sysGet("mambanet", fresh)).filter((n) => n.slot_nr != null).sort((a, b) => a.slot_nr - b.slot_nr);
    body.innerHTML = table(["Slot", "Naam", "Unique ID (hex)", "Unique ID (dec)"],
      d.map((n) => `<tr class="${n.active ? "" : "inactive"}"><td>${n.slot_nr}</td><td><b>${esc(n.name)}</b></td>
        <td><code>${uid(n.man, n.prod, n.uid)}</code></td><td><code>${n.man}.${n.prod}.${n.uid}</code></td></tr>`));
  },
  async templates(body, fresh) {
    const d = await sysGet("templates", fresh);
    body.innerHTML = `<p class="empty">Klik op een template voor alle objecten (sensoren/actuatoren) van dat kaarttype.</p>` +
      table(["Fabrikant", "Product", "Firmware", "Objecten", "Gebruikt door", "Aantal nodes"],
        d.map((t) => `<tr class="click" data-k="${t.man_id}/${t.prod_id}/${t.firm_major}"><td><code>${hex(t.man_id).slice(-4)}</code></td>
          <td><code>${hex(t.prod_id).slice(-4)}</code></td><td>${t.firm_major}</td><td>${t.count}</td>
          <td>${esc(t.node_name ?? "–")}</td><td>${t.nodes}</td></tr>`)) + '<div id="tpl-detail"></div>';
    body.querySelectorAll("tr.click").forEach((tr) => (tr.onclick = async () => {
      body.querySelectorAll("tr.click").forEach((x) => x.classList.toggle("sel", x === tr));
      const rows = await sysGet("templates/" + tr.dataset.k);
      const hasCnt = rows.some((r) => r.description === "Input channel count");
      $("tpl-detail").innerHTML = `<h3>Template ${esc(tr.dataset.k.replaceAll("/", " · "))} <small>${rows.length} objecten</small></h3>
        <p class="${hasCnt ? "" : "warnline"}">${hasCnt ? "✓ Dit kaarttype meldt zijn kanaalaantal (object 1025/1026)." : "✗ Dit kaarttype heeft géén object \"Input/Output channel count\": de engine kan het aantal kanalen niet uitlezen."}</p>` +
        table(["Object", "Beschrijving", "Services", "Sensor", "Bereik", "Actuator", "Bereik", "Standaard"],
          rows.map((r) => `<tr class="${/channel count|Slot number/.test(r.description) ? "hlrow" : ""}"><td><code>${r.number}</code></td><td>${esc(r.description)}</td><td>${r.services}</td>
            <td>${r.sensor_type ? esc(r.sensor) : '<span class="empty">–</span>'}</td><td>${esc(r.sensor_range)}</td>
            <td>${r.actuator_type ? esc(r.actuator) : '<span class="empty">–</span>'}</td><td>${esc(r.actuator_range)}</td><td>${r.actuator_default ?? ""}</td></tr>`));
      $("tpl-detail").scrollIntoView({ behavior: "smooth" });
    }));
  },
  async predefined(body, fresh) {
    const d = await sysGet("predefined", fresh);
    const nodes = (await sysGet("mambanet")).reduce((m, n) => ((m[`${n.man}/${n.prod}/${n.firm_major}`] ||= []).push(n.name), m), {});
    body.innerHTML = `<p class="empty">Opgeslagen functie-sets die je in Rack-configuratie kunt importeren. Zie het tabblad Kaart-functies voor de juiste offset.</p>` +
      table(["Fabrikant", "Product", "Firmware", "Naam", "Functies", "Defaults", "Past op kaart(en)"],
        d.map((p) => `<tr><td><code>${hex(p.man_id).slice(-4)}</code></td><td><code>${hex(p.prod_id).slice(-4)}</code></td><td>${p.firm_major}</td>
          <td><b>${esc(p.cfg_name)}</b></td><td>${p.config}</td><td>${p.defaults}</td>
          <td>${esc((nodes[`${p.man_id}/${p.prod_id}/${p.firm_major}`] || []).join(", ")) || '<span class="empty">geen</span>'}</td></tr>`));
  },
  async functions(body, fresh) {
    const d = await sysGet("functions", fresh);
    const types = [...new Set(d.map((f) => f.type))];
    const TN = { 0: "Module", 1: "Bus", 2: "Monitorbus", 3: "Console", 4: "Globaal", 5: "Bron", 6: "Bestemming" };
    body.innerHTML = `<div class="toolbar"><div class="seg" id="ft-types">${types.map((t, i) => `<button data-t="${t}" class="${i ? "" : "active"}">${TN[t] ?? t} <small>(${d.filter((f) => f.type === t).length})</small></button>`).join("")}</div>
      <input id="ft-search" type="search" placeholder="zoek functie…"></div><div id="ft-table"></div>`;
    let type = types[0];
    const draw = () => {
      const q = $("ft-search").value.toLowerCase();
      const rows = d.filter((f) => (q ? true : f.type === type) && (!q || f.name.toLowerCase().includes(q) || (f.label || "").toLowerCase().includes(q)));
      $("ft-table").innerHTML = table(["Soort", "Nr", "Functie", "Label", "Ontvangt", "Zendt", ...LEVELS],
        rows.map((f) => `<tr><td>${TN[f.type] ?? f.type}</td><td>${f.func}</td><td><b>${esc(f.name)}</b></td><td>${esc(f.label)}</td>
          <td>${esc(f.rcv)}</td><td>${esc(f.xmt)}</td>${[0, 1, 2, 3, 4, 5].map((l) => `<td class="c">${f.rcv_type ? yn(f["user_level" + l]) : ""}</td>`).join("")}</tr>`));
    };
    body.querySelectorAll("#ft-types button").forEach((b) => (b.onclick = () => {
      type = +b.dataset.t; $("ft-search").value = "";
      body.querySelectorAll("#ft-types button").forEach((x) => x.classList.toggle("active", x === b)); draw();
    }));
    $("ft-search").oninput = draw;
    draw();
  },
  async logs(body) {
    const names = { engine: "Engine", gateway: "Gateway", address: "Address server", learner: "Learner", postgresql: "PostgreSQL" };
    body.innerHTML = `<div class="toolbar"><div class="seg" id="lg-names">${Object.entries(names).map(([k, v], i) => `<button data-n="${k}" class="${i ? "" : "active"}">${v}</button>`).join("")}</div>
      <select id="lg-lines"><option>200</option><option selected>500</option><option>2000</option><option>5000</option></select>
      <input id="lg-filter" type="search" placeholder="filter, bijv. 0x00000001 of slot">
      <button id="lg-reload" class="btn">Vernieuwen</button></div><div id="lg-info" class="empty"></div><pre id="lg-text" class="logtext"></pre>`;
    let name = "engine", data = null;
    const draw = () => {
      const q = $("lg-filter").value.toLowerCase();
      const lines = q ? data.lines.filter((l) => l.toLowerCase().includes(q)) : data.lines;
      $("lg-info").textContent = `${data.file}: laatste ${data.lines.length} van ${data.total} regels${q ? `, ${lines.length} gevonden` : ""}`;
      $("lg-text").innerHTML = lines.map((l) => {
        const cls = /error|fail|wrong|timeout/i.test(l) ? "le" : /warn|retr/i.test(l) ? "lw" : "";
        return `<span class="${cls}">${esc(l)}</span>`;
      }).join("\n");
      $("lg-text").scrollTop = $("lg-text").scrollHeight;
    };
    const fetchLog = async () => {
      $("lg-info").textContent = "laden…";
      const r = await fetch(`/api/system/logs/${name}?lines=${$("lg-lines").value}`);
      data = await r.json();
      if (!r.ok) { $("lg-info").textContent = data.detail; return; }
      draw();
    };
    body.querySelectorAll("#lg-names button").forEach((b) => (b.onclick = () => {
      name = b.dataset.n; body.querySelectorAll("#lg-names button").forEach((x) => x.classList.toggle("active", x === b)); fetchLog();
    }));
    $("lg-lines").onchange = fetchLog; $("lg-reload").onclick = fetchLog; $("lg-filter").oninput = () => data && draw();
    fetchLog();
  },
  async versions(body, fresh) {
    const d = await sysGet("versions", fresh);
    body.innerHTML = table(["Pakket", "Versie", "Gebouwd", "Geïnstalleerd"],
      d.map((p) => `<tr><td><b>${esc(p.name)}</b></td><td><code>${esc(p.version)}</code></td><td>${esc(p.build)}</td><td>${esc(p.installed)}</td></tr>`));
  },
};

// ---------- surface: virtuele knoppen/faders + signaalpad (simulatie) ----------
// Knoppen en faders worden door de engine NIET in Postgres opgeslagen; de echte stand zit
// alleen in het geheugen van de engine. Deze weergave start vanuit de database-stand
// (module_config / monitor_buss_config) en laat zien wat er gebeurt als je iets bedient.
let surfSel = null, sim = null, surfEdges = [];
// live MambaNet: waardes per node -> object
let liveES = null, liveOn = false, liveStatus = "uit", liveLog = [], liveRAF = 0, surfFuncs = {};
const live = { lit: {}, text: {}, pos: {}, meter: {}, last: {} };   // lit/text/pos: [node][obj]; meter: [module]{L,R,t}
let showAllModules = false, lastFlowHtml = "";
// functies van alle surfaces: node -> object -> functie (voor meters van alle surfaces)
const surfFuncAll = () => {
  const out = {};
  S.functions.forEach((x) => { if (byAddr[x.addr]?.surface) out[x.addr] = Object.fromEntries(x.functions.map((f) => [f.object, f])); });
  return out;
};
let funcAllCache = null;
let backup = null, backupBusy = false;          // startstand uit /var/lib/axum/.backup

async function loadBackup() {
  if (backupBusy) return;
  backupBusy = true;
  try {
    const r = await fetch("/api/mbn/backup");
    backup = r.ok ? await r.json() : { error: "HTTP " + r.status };
  } catch (e) { backup = { error: e.message }; }
  backupBusy = false;
  initSim();
  if (S) { renderSurface(); renderModules(); }
}
const BUS_RE = /^Buss (\d+)\/(\d+) on\/off$/;
const busIdx = (name) => { const m = BUS_RE.exec(name); return m ? (+m[1] - 1) / 2 : null; };  // "Buss 3/4 on/off" -> 1
const busName = (i) => S.busses.find((b) => b.number === i + 1)?.label ?? `Bus ${i * 2 + 1}/${i * 2 + 2}`;
const monName = (k) => S.monitor.find((m) => m.number === k)?.label ?? `Monitorbus ${k}`;

function initSim() {
  sim = { mod: {}, mon: {}, pressed: null };
  const bk = backup?.modules ? Object.fromEntries(backup.modules.map((m) => [m.number, m])) : {};
  S.modules.forEach((m) => {
    const b = bk[m.number];
    sim.mod[m.number] = {
      on: !!m.mod_on_off, level: b ? b.level : m.mod_level ?? -140,
      bus: b ? b.bus_on.slice() : m.busses.map((x) => !!x.on),
      eq: !!m.eq_on_off, dyn: !!m.dyn_on_off, preset: 0, src: b ? b.source : null };
  });
  const bkMon = backup?.monitors ? Object.fromEntries(backup.monitors.map((m) => [m.number, m])) : {};
  S.monitor.forEach((mb) => (sim.mon[mb.number] = { bus: bkMon[mb.number] ? bkMon[mb.number].bus.slice() : mb.busses.map(Boolean) }));
  // Start aan/uit per bron (matrix-nummer = bron + 288)
  sim.start = {};
  (backup?.sources || []).forEach((x) => (sim.start[x.number + 288] = x.start));
}

function ctrlKind(f) {
  const d = f.description || "";
  if (/^Fader/i.test(d)) return "fader";
  if (/^Display Meter/i.test(d) || f.name === "Peak" || /meter \d+ (left|right) dB$/i.test(d) || /^Audio level (left|right)$/.test(f.name)) return "meter";
  if (/Meter \d+ Label|Phase Meter/i.test(d)) return "display";
  if (/^Display/i.test(d)) return "display";
  if (/^Potential Meter/i.test(d)) return "pot";
  if (/^Encoder \d+$/i.test(d)) return "encoder";
  if (/color/i.test(d)) return "led";
  return "button";
}
const KIND_ORDER = { display: 0, meter: 1, encoder: 2, pot: 2, button: 3, led: 4, fader: 5 };

function ctrlLabel(f) {
  const bi = busIdx(f.name);
  if (bi != null) return busName(bi);
  const short = { "EQ on/off": "EQ", "Dynamics on/off": "DYN", "Module preset A/B": "A/B", "Source start/stop": "START",
    "Talkback 1 to related destination": "TB→", "Talkback 1": "TB 1", "Control reset": "⟲", "Module on/off": "ON", Reset: "Reset" };
  if (short[f.name]) return short[f.name];
  if (ctrlKind(f) === "encoder") return "◎ encoder";
  return f.name.replace(/^Control mode /, "").replace(/^Console preset /, "Preset ");
}

// is deze knop nu "aan" in de simulatie?
function ctrlLit(f) {
  const n = f.seq + 1, bi = busIdx(f.name);
  if (f.type === 0) {
    const st = sim.mod[n]; if (!st) return false;
    if (bi != null) return st.bus[bi];
    if (f.name === "EQ on/off") return st.eq;
    if (f.name === "Dynamics on/off") return st.dyn;
    if (f.name === "Module on/off") return st.on;
    if (f.name === "Module preset A/B") return st.preset === 1;
    if (f.name === "Source start/stop" && live.lit[surfSel]?.[f.object] == null) {
      const M = S.modules.find((m) => m.number === n);
      return !!sim.start?.[st.src ?? M?.sources[st.preset]];
    }
  }
  if (f.type === 2 && bi != null) return !!sim.mon[n]?.bus[bi];
  const l = live.lit[surfSel]?.[f.object];
  if (l != null) return l;
  return sim.pressed?.object === f.object;
}

function surfaceList() {
  return S.functions.filter((x) => byAddr[x.addr]?.surface && x.functions.length);
}

function renderSurface() {
  if (!sim) initSim();
  if (!backup && !backupBusy) loadBackup();
  const list = surfaceList();
  if (!list.length) { $("surface").innerHTML = '<span class="empty">Geen surface met functies gevonden.</span>'; return; }
  if (!list.some((x) => x.addr === surfSel)) surfSel = list[0].addr;
  $("surf-select").innerHTML = list.map((x) => `<button data-a="${x.addr}" class="${x.addr === surfSel ? "active" : ""}">${esc(x.name)} <small>${hex(x.addr)} · ${byAddr[x.addr].unique_id}</small></button>`).join("")
    + `<button id="surf-live" class="${liveOn ? "active" : ""}" title="Lees via SSH live mee op MambaNet (alleen lezen)">${liveOn ? "● Live aan" : "○ Live uit"}</button>`
    + `<span class="live-status ${liveStatus}">${esc({ uit: "", start: "starten…", verbinden: "verbinden met engine…", live: "live: luistert mee op MambaNet", fout: "fout" }[liveStatus] ?? liveStatus)}</span>`
    + `<button id="surf-reset" title="Lees de stand opnieuw uit /var/lib/axum/.backup op de engine">↺ stand van de engine</button>`;
  $("surf-select").querySelectorAll("button[data-a]").forEach((b) => (b.onclick = () => { surfSel = +b.dataset.a; sim.pressed = null; renderSurface(); }));
  $("surf-reset").onclick = () => { backup = null; live.lit = {}; live.text = {}; live.pos = {}; if (sim) sim.pot = {}; loadBackup(); };
  $("surf-live").onclick = () => toggleLive();

  const node = byAddr[surfSel], sf = list.find((x) => x.addr === surfSel);
  const bkLine = backupBusy ? "Stand van de engine wordt gelezen…"
    : backup?.error ? `<span class="warn">Stand van de engine niet gelezen: ${esc(backup.error)} — de stand komt nu uit de database.</span>`
    : backup ? `Startstand: faders, bus aan/uit, bron, Start en monitorkeuze uit <code>/var/lib/axum/.backup</code> van
        <b>${new Date(backup.mtime * 1000).toLocaleTimeString("nl-NL")}</b> (de engine schrijft dit elke 30 s bij wijzigingen).` : "";
  $("surf-note").innerHTML = `<div>${bkLine}</div>` + (liveOn ? `<b>Live.</b> AXUM Inzicht leest via SSH mee met het MambaNet-verkeer tussen de surface en de engine
    (UDP 34848, alleen lezen). Knoppen, faders en displays volgen wat de engine terugstuurt. Waardes verschijnen pas als er iets verandert;
    wat je nog niet hebt aangeraakt blijft op de startstand.
    ${node.active ? '<span class="tag on">surface online</span>' : '<span class="tag bad">surface staat offline in de database</span>'}` : `<b>Simulatie.</b> Klik hier op knoppen en faders om te zien wat er
    met het signaalpad gebeurt; dat verandert niets op de mixer. Zet <b>Live</b> aan om de echte surface te volgen.
    ${node.active ? '<span class="tag on">surface online</span>' : '<span class="tag bad">surface staat offline in de database</span>'}`);

  // functies groeperen: modules per strip, de rest per (type, seq)
  const seen = new Set(), funcs = sf.functions.filter((f) => !seen.has(f.object) && seen.add(f.object));
  surfFuncs = Object.fromEntries(funcs.map((f) => [f.object, f]));
  const groups = new Map();
  funcs.forEach((f) => {
    const key = f.type === 0 ? `m${f.seq}` : `t${f.type}-${f.seq}`;
    if (!groups.has(key)) groups.set(key, { type: f.type, seq: f.seq, items: [] });
    groups.get(key).items.push(f);
  });
  const sorted = [...groups.values()].sort((a, b) => (a.type === 0) === (b.type === 0) ? a.type - b.type || a.seq - b.seq : a.type === 0 ? -1 : 1);
  const title = (g) => g.type === 0 ? `Module ${g.seq + 1}` : g.type === 2 ? monName(g.seq + 1)
    : g.type === 1 ? busName(g.seq) : g.type === 3 ? `Console ${g.seq + 1}` : g.type === 4 ? "Globaal" : FUNC_NAME(g.type);

  $("surface").innerHTML = sorted.map((g) => {
    const items = g.items.slice().sort((a, b) => KIND_ORDER[ctrlKind(a)] - KIND_ORDER[ctrlKind(b)] || a.object - b.object);
    return `<div class="sstrip ${g.type === 0 ? "mod" : "master"}"><h4>${esc(title(g))}</h4>${items.map(ctrlHTML).join("")}</div>`;
  }).join("");
  $("surface").querySelectorAll("[data-o]").forEach((el) => {
    const f = funcs.find((x) => x.object === +el.dataset.o);
    if (el.tagName === "INPUT") el.oninput = () => onFader(f, +el.value, el);
    else if (el.classList.contains("knob")) wireKnob(f, el);
    else if (el.tagName === "BUTTON") el.onclick = () => onButton(f, el);
  });
  renderSurfPath();
}
const FUNC_NAME = (t) => ({ 0: "Module", 1: "Bus", 2: "Monitorbus", 3: "Console", 4: "Globaal", 5: "Bron", 6: "Bestemming" }[t] ?? "type " + t);

// Fader-curve zoals de schaal op de Axite-surface (afgemeten van de screenshot):
// schaal-label L staat voor +10-L dB (0 = +10 dB, 10 = 0 dB); fractie = hoogte vanaf onder (0 = ∞)
const TAPER = [[-60, 0], [-50, 0.096], [-30, 0.273], [-20, 0.388], [-10, 0.512], [-5, 0.627], [0, 0.762], [5, 0.877], [10, 1]];
// officiële curve uit de tabel db_to_position (dB -> stand 0..1023); TAPER is de reserve
function dbToFrac(d) {
  const c = S?.curve;
  if (c?.length) {
    if (d <= c[0][0]) return 0;
    let lo = 0, hi = c.length - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (c[mid][0] <= d) lo = mid; else hi = mid - 1; }
    return c[lo][1] / 1023;
  }
  if (d <= -60) return 0;
  for (let i = 1; i < TAPER.length; i++) {
    const [d0, f0] = TAPER[i - 1], [d1, f1] = TAPER[i];
    if (d <= d1) return f0 + (f1 - f0) * (d - d0) / (d1 - d0);
  }
  return 1;
}
function fracToDb(fr) {
  const c = S?.curve;
  if (c?.length) {
    const p = Math.round(fr * 1023);
    if (p <= 0) return -140;
    const hit = c.find((x) => x[1] >= p);          // laagste dB met deze stand
    return hit ? hit[0] : c[c.length - 1][0];
  }
  if (fr <= 0.005) return -140;
  for (let i = 1; i < TAPER.length; i++) {
    const [d0, f0] = TAPER[i - 1], [d1, f1] = TAPER[i];
    if (fr <= f1) return Math.round((d0 + (d1 - d0) * (fr - f0) / (f1 - f0)) * 10) / 10;
  }
  return 10;
}
// schaal in echte dB van de engine (zelfde posities als de Axite-schaal 0..60..∞)
const FADER_MARKS = [[10, "+10"], [5, "+5"], [0, "0"], [-5, "-5"], [-10, "-10"], [-20, "-20"], [-30, "-30"], [-50, "-50"], [-140, "-∞"]];
const fy = (d) => `calc(13px + ${dbToFrac(d).toFixed(4)} * (100% - 26px))`;   // 13 px = halve knop
const faderTicks = () => `<div class="fticks">${FADER_MARKS.map(([L]) => `<i style="bottom:${fy(L)}"></i>`).join("")}</div>`;
const faderScale = () => `<div class="fscale">${FADER_MARKS.map(([L, t]) => `<span style="bottom:${fy(L)}">${t}</span>`).join("")}</div>`;

// draaiknop: 0..1023 -> -135..+135 graden
const knobAngle = (p) => (-135 + 270 * Math.max(0, Math.min(1023, p)) / 1023).toFixed(1);
function setKnob(f, el, p) {
  p = Math.round(Math.max(0, Math.min(1023, p)));
  (sim.pot ||= {})[f.object] = p;
  el.style.setProperty("--a", knobAngle(p) + "deg");
  el.parentElement.querySelector(".pv").textContent = Math.round(p / 10.23) + "%";
  sim.pressed = { object: f.object, text: `<code>obj ${f.object}</code> ${esc(f.description)} → ${esc(f.name)} van <b>${esc(monName(f.seq + 1))}</b>: ${Math.round(p / 10.23)}% — alleen volume, verandert het signaalpad niet` };
  renderSurfPath();
  const pe = $("surf-explain").querySelector(".pressed"); if (pe) pe.innerHTML = sim.pressed.text;
}
function wireKnob(f, el) {
  const cur = () => sim.pot?.[f.object] ?? live.pos[surfSel]?.[f.object] ?? 0;
  el.onpointerdown = (e) => {
    el.setPointerCapture(e.pointerId);
    const y0 = e.clientY, p0 = cur();
    el.onpointermove = (ev) => setKnob(f, el, p0 + (y0 - ev.clientY) * 6);   // omhoog slepen = harder
    el.onpointerup = () => { el.onpointermove = null; };
  };
  el.onwheel = (e) => { e.preventDefault(); setKnob(f, el, cur() - Math.sign(e.deltaY) * 40); };
  el.onkeydown = (e) => { if (e.key === "ArrowUp" || e.key === "ArrowRight") setKnob(f, el, cur() + 20); if (e.key === "ArrowDown" || e.key === "ArrowLeft") setKnob(f, el, cur() - 20); };
}

function ctrlHTML(f) {
  const k = ctrlKind(f), tip = esc(`${f.description} (object ${f.object}) → ${f.name} · ${f.target}`);
  if (k === "pot") {
    const bm = backup?.monitors?.find((x) => x.number === f.seq + 1);
    const bdb = bm ? (/^Phones/.test(f.name) ? bm.phones : /^Speaker/.test(f.name) ? bm.speaker : null) : null;
    const pos = live.pos[surfSel]?.[f.object] ?? sim.pot?.[f.object] ?? (bdb != null ? Math.round(dbToFrac(bdb) * 1023) : 0);   // 0..1023
    return `<div class="ctl pot" title="${tip}${bdb != null ? " · engine: " + db(bdb) : ""}"><span class="pl">${esc(f.name.replace(/ level$/, ""))}</span>
      <div class="knob" data-o="${f.object}" tabindex="0" style="--a:${knobAngle(pos)}deg"><i></i></div>
      <span class="pv">${Math.round(pos / 10.23)}%</span></div>`;
  }
  if (k === "fader") {
    const st = f.type === 0 ? sim.mod[f.seq + 1] : null;
    const pos = live.pos[surfSel]?.[f.object];
    const v = k === "fader"
      ? Math.round(1000 * (pos != null ? pos / 1023 : dbToFrac(st ? st.level : -140)))   // fader: 0..1000 volgens de curve
      : pos != null ? -60 + 70 * pos / 1023 : -60;
    return `<label class="ctl ${k === "fader" ? "sfader" : k}" title="${tip}"><span>${k === "fader" ? (pos != null ? posText(pos) : db(st ? st.level : -140)) : esc(f.name)}</span>
      ${k === "fader" ? `<div class="fbody">${faderTicks()}<span class="fwrap">` : ""}<input type="range" ${k === "fader" ? 'min="0" max="1000" step="1"' : 'min="-60" max="10" step="0.5"'} value="${v}" data-o="${f.object}">${k === "fader" ? `</span>${faderScale()}</div>` : ""}</label>`;
  }
  if (k === "meter") {
    const side = /right/i.test(f.name + f.description) ? "R" : /left/i.test(f.name + f.description) ? "L" : null;
    if (!side) return "";                                   // Peak-lampje niet apart tonen
    const key = f.type === 0 ? String(f.seq + 1) : "b" + (f.seq + 1);   // module-meter of bus-meter
    const v = live.meter[key]?.[side];
    return `<div class="ctl meter" title="${tip}"><i data-meter="${key}${side}" style="width:${meterPct(v)}%"></i>
      <span data-meterdb="${key}${side}">${v == null ? "" : v <= -50 ? "-∞" : v.toFixed(0)}</span></div>`;
  }
  if (k === "display") {
    const st = f.type === 0 ? S.modules.find((m) => m.number === f.seq + 1) : null;
    const sm = sim.mod[f.seq + 1];
    const txt = /Line 1/.test(f.description) ? `Mod ${f.seq + 1}` : st ? label(sm.src ?? st.sources[sm.preset]) : "";
    const lt = live.text[surfSel]?.[f.object];
    return `<div class="ctl display ${lt != null ? "live" : ""}" title="${tip}">${esc(lt ?? txt)}</div>`;
  }
  if (k === "led") return "";
  return `<button class="ctl btn ${ctrlLit(f) ? "lit" : ""}" data-o="${f.object}" title="${tip}">${esc(ctrlLabel(f))}</button>`;
}

function onFader(f, v, el) {
  if (f.type === 0) {
    const st = sim.mod[f.seq + 1]; if (!st) return;
    st.level = fracToDb(v / 1000);
    el.closest('.ctl').querySelector('span').textContent = db(st.level);
    sim.pressed = { object: f.object, text: `<code>obj ${f.object}</code> ${f.description} → <b>Module ${f.seq + 1}</b> niveau ${db(st.level)}` };
  } else {
    sim.pressed = { object: f.object, text: `<code>obj ${f.object}</code> ${f.description} → ${esc(f.name)} van <b>${esc(monName(f.seq + 1))}</b>: alleen volume, verandert het signaalpad niet` };
  }
  renderSurfPath();
}

function onButton(f, el) {
  const n = f.seq + 1, bi = busIdx(f.name);
  let text = `<code>obj ${f.object}</code> ${esc(f.description)} → <b>${esc(f.name)}</b>`;
  if (f.type === 0 && sim.mod[n]) {
    const st = sim.mod[n], M = S.modules.find((m) => m.number === n);
    if (bi != null) {
      st.bus[bi] = !st.bus[bi];
      text += ` op Module ${n}: naar <b>${esc(busName(bi))}</b> ${st.bus[bi] ? "AAN" : "UIT"}`;
      if (!M.busses[bi]?.assigned) text += ` <span class="warn">(maar Module ${n} is in de configuratie niet aan ${esc(busName(bi))} toegewezen, dus er gebeurt niets)</span>`;
    } else if (f.name === "EQ on/off") { st.eq = !st.eq; text += ` Module ${n}: ${st.eq ? "aan" : "uit"} (klankkleur, geen ander pad)`; }
    else if (f.name === "Dynamics on/off") { st.dyn = !st.dyn; text += ` Module ${n}: ${st.dyn ? "aan" : "uit"} (geen ander pad)`; }
    else if (f.name === "Module on/off") { st.on = !st.on; text += ` Module ${n}: ${st.on ? "AAN" : "UIT"}`; }
    else if (f.name === "Module preset A/B") {
      st.preset = st.preset ? 0 : 1; st.src = M.sources[st.preset];
      text += ` Module ${n}: bron ${st.preset ? "B" : "A"} = <b>${esc(label(st.src))}</b>`;
    } else if (f.name === "Source start/stop") {
      const sn = st.src ?? M.sources[st.preset];
      sim.start[sn] = !sim.start[sn];
      text += ` voor ${esc(label(sn))} (Module ${n}): ${sim.start[sn] ? "START" : "STOP"} — stuurt een start/stop-GPO, geen audiopad`;
    }
    else if (/Talkback/.test(f.name)) text += `: talkback naar de bestemming die bij de bron van Module ${n} hoort (related destination)`;
    else text += ` (Module ${n})`;
  } else if (f.type === 2 && bi != null && sim.mon[n]) {
    sim.mon[n].bus[bi] = !sim.mon[n].bus[bi];
    text += `: <b>${esc(monName(n))}</b> luistert ${sim.mon[n].bus[bi] ? "nu" : "niet meer"} naar <b>${esc(busName(bi))}</b>`;
  } else if (f.type === 3) text += `: bepaalt wat de draaiknoppen (encoders) op de strips regelen. Verandert het signaalpad niet.`;
  else if (f.type === 4) text += `: laadt een console-preset (zet in één keer veel knoppen om; niet gesimuleerd).`;
  else text += ` (${esc(f.target)})`;
  sim.pressed = { object: f.object, text };
  renderSurface();
}

// PPM: -50 dB = 0 %, +10 dB = 100 %
const meterPct = (v) => (v == null ? 0 : Math.max(0, Math.min(100, (v + 50) / 60 * 100)));
function updateMeter(mod, side, v) {
  document.querySelectorAll(`[data-meter="${mod}${side}"]`).forEach((el) => {
    el.style[el.parentElement.classList.contains("vmeter") ? "height" : "width"] = meterPct(v) + "%";
    el.classList.toggle("hot", v > 0);
  });
  document.querySelectorAll(`[data-meterdb="${mod}${side}"]`).forEach((el) => (el.textContent = v <= -50 ? "-∞" : v.toFixed(0)));
}
// meters die al 2 s niets meer kregen naar nul laten zakken
setInterval(() => {
  const now = Date.now();
  Object.entries(live.meter).forEach(([mod, mt]) => { if (now - mt.t > 2000 && (mt.L > -50 || mt.R > -50)) { mt.L = mt.R = -60; updateMeter(mod, "L", -60); updateMeter(mod, "R", -60); } });
}, 1000);

const posText = (p) => db(fracToDb(p / 1023));   // ruwe fader-stand -> dB volgens de fader-curve

function toggleLive() {
  liveOn = !liveOn;
  if (liveOn) {
    liveES = new EventSource("/api/mbn/events");
    liveES.onmessage = (e) => onLive(JSON.parse(e.data));
    liveES.onerror = () => { liveStatus = "verbinden"; scheduleSurface(); };
  } else {
    liveES?.close(); liveES = null; liveStatus = "uit";
  }
  renderSurface(); renderModules();
}
function scheduleSurface() {
  if (!liveRAF) liveRAF = requestAnimationFrame(() => { liveRAF = 0; renderSurface(); if ($("view-modules").classList.contains("active")) renderModules(); });
}
function onLive(m) {
  if (m.kind === "status") { liveStatus = m.status; if (m.error) liveLog.unshift({ err: m.error }); scheduleSurface(); return; }
  if (m.kind !== "mbn") return;
  const node = m.node, isAct = m.act === "set_actuator" || m.act === "actuator_response";
  const isSens = m.act === "sensor_changed" || m.act === "sensor_response";
  if (!isAct && !isSens) return;
  funcAllCache ||= surfFuncAll();
  const fa = funcAllCache[node]?.[m.obj];
  // meters: alleen de meter zelf bijwerken, niets opnieuw tekenen
  if (fa && ctrlKind(fa) === "meter" && fa.name !== "Peak" && typeof m.val === "number") {
    const mod = fa.type === 0 ? String(fa.seq + 1) : "b" + (fa.seq + 1), side = /right/i.test(fa.name + fa.description) ? "R" : "L";
    (live.meter[mod] ||= {})[side] = m.val; live.meter[mod].t = Date.now();
    updateMeter(mod, side, m.val);
    return;
  }
  // alleen verder als er echt iets veranderd is (de engine herhaalt lampjes elke seconde)
  const key = node + ":" + m.obj + ":" + (isAct ? "a" : "s");
  if (!m.replay && live.last[key] === m.val && !(isSens && typeof m.val === "number" && fa && ctrlKind(fa) === "button")) return;
  live.last[key] = m.val;
  const f = node === surfSel ? surfFuncs[m.obj] : null;
  if (!f && !fa) return;
  const kind = f ? ctrlKind(f) : null;
  if (kind === "fader" || kind === "pot") {
    if (typeof m.val === "number") (live.pos[node] ||= {})[m.obj] = m.val;
    if (f.type === 0 && sim.mod[f.seq + 1] && typeof m.val === "number") sim.mod[f.seq + 1].level = m.val > 0 ? 0 : -140;
  } else if (kind === "display") {
    if (isAct) (live.text[node] ||= {})[m.obj] = String(m.val);
  } else if (f && isAct && typeof m.val === "number") {
    // de engine zet het lampje: dat is de echte stand
    const on = m.val !== 0, n = f.seq + 1, bi = busIdx(f.name);
    if (f.type === 0 && sim.mod[n] && bi != null) sim.mod[n].bus[bi] = on;
    else if (f.type === 0 && sim.mod[n] && f.name === "EQ on/off") sim.mod[n].eq = on;
    else if (f.type === 0 && sim.mod[n] && f.name === "Dynamics on/off") sim.mod[n].dyn = on;
    else if (f.type === 0 && sim.mod[n] && f.name === "Module on/off") sim.mod[n].on = on;
    else if (f.type === 2 && sim.mon[n] && bi != null) sim.mon[n].bus[bi] = on;
    else (live.lit[node] ||= {})[m.obj] = on;
  }
  if (!m.replay && f && !(kind === "display")) {
    const what = kind === "fader" ? posText(m.val) : kind === "pot" ? Math.round(m.val / 10.23) + "%" : isAct ? (m.val ? "lampje AAN" : "lampje uit") : (m.val ? "ingedrukt" : "losgelaten");
    liveLog.unshift({ t: m.t, dir: m.dir, f, what });
    liveLog.length = Math.min(liveLog.length, 10);
    sim.pressed = { object: f.object, text: `<span class="tag on">LIVE</span> <code>obj ${f.object}</code> ${esc(f.description)} → <b>${esc(f.name)}</b> (${esc(f.target)}): ${what}` };
  }
  if (node === surfSel) scheduleSurface();
}

function renderSurfPath() {
  const sf = surfaceList().find((x) => x.addr === surfSel); if (!sf) return;
  const mods = [...new Set(sf.functions.filter((f) => f.type === 0).map((f) => f.seq + 1))].sort((a, b) => a - b);
  const monsOnSurface = new Set(sf.functions.filter((f) => f.type === 2).map((f) => f.seq + 1));
  const cols = [[], [], [], [], [], []], boxes = {};
  surfEdges = [];
  const box = (col, id, title, sub, cls = "") => { if (!boxes[id]) { boxes[id] = { col, id, title, sub, cls, on: false }; cols[col].push(boxes[id]); } return boxes[id]; };
  const edge = (a, b, on) => { surfEdges.push([a, b, on]); if (on) boxes[b].on = true; };

  mods.forEach((n) => {
    const M = S.modules.find((m) => m.number === n), st = sim.mod[n]; if (!M || !st) return;
    const open = st.on && st.level > -138;   // fader helemaal omlaag = -138,1 dB in de engine
    const src = st.src ?? M.sources[st.preset];
    const sid = src > 0 ? "ss-" + src : "ss-none-" + n;
    const s = box(0, sid, src > 0 ? esc(label(src)) : "geen bron", src > 0 ? `actuele bron van module ${n}` : `module ${n} heeft geen bron gekozen`, src > 0 ? "in" : "dim");
    s.on = src > 0;
    const lp = Object.values(surfFuncs).find((f) => f.type === 0 && f.seq + 1 === n && ctrlKind(f) === "fader");
    const lpos = lp ? live.pos[surfSel]?.[lp.object] : null;
    const mb = box(1, "sm-" + n, `Module ${n}`, `${lpos != null ? "fader " + posText(lpos) : db(st.level)} · ${st.on ? "aan" : "uit"}${st.eq ? " · EQ" : ""}${st.dyn ? " · DYN" : ""}`, "mod");
    surfEdges.push([sid, "sm-" + n, open]); mb.on = open;
    M.busses.forEach((b, i) => {
      if (!b.assigned) return;
      box(2, "sb-" + (i + 1), esc(busName(i)), `bus ${i * 2 + 1}/${i * 2 + 2}`, "bus");
      edge("sm-" + n, "sb-" + (i + 1), open && st.bus[i]);
    });
  });
  // monitorbussen: luisteren naar geselecteerde bussen
  S.monitor.forEach((mb) => {
    const k = mb.number, used = monsOnSurface.has(k) || S.dests.some((d) => d.source === 16 + k);
    if (!used) return;
    box(3, "sn-" + k, esc(mb.label), `monitorbus ${k}`, "bus");
    sim.mon[k].bus.forEach((sel, i) => { if (sel && boxes["sb-" + (i + 1)]) edge("sb-" + (i + 1), "sn-" + k, boxes["sb-" + (i + 1)].on); });
  });
  S.dests.forEach((d) => {
    let from = null;
    if (d.source >= 1 && d.source <= 16) from = "sb-" + d.source;
    else if (d.source >= 17 && d.source <= 32) from = "sn-" + (d.source - 16);
    else if (d.source > 288) from = "ss-" + d.source;
    if (!from || !boxes[from]) return;
    box(4, "sd-" + d.number, esc(d.label), `bestemming ${d.number}`, "");
    edge(from, "sd-" + d.number, boxes[from].on);
    if (d.output1_addr) {
      const c = byAddr[d.output1_addr];
      box(5, "so-" + d.number, c ? esc(c.name) : hex(d.output1_addr), `slot ${c?.slot_nr ?? "–"} · kanaal ${d.output1_sub_ch}${d.output2_sub_ch && d.output2_sub_ch !== d.output1_sub_ch ? "/" + d.output2_sub_ch : ""}`, "out");
      edge("sd-" + d.number, "so-" + d.number, boxes["sd-" + d.number].on);
    }
  });

  // uitleg: wat is er nu hoorbaar
  const reach = (id, acc = new Set()) => { surfEdges.forEach(([a, b, on]) => on && a === id && !acc.has(b) && (acc.add(b), reach(b, acc))); return acc; };
  const lines = mods.map((n) => {
    if (!boxes["sm-" + n]?.on) return null;
    const outs = [...reach("sm-" + n)].filter((id) => id.startsWith("sd-")).map((id) => boxes[id].title);
    const src = boxes[surfEdges.find(([a, b]) => b === "sm-" + n)?.[0]];
    return `Module ${n}${src && src.cls === "in" ? ` (${src.title})` : ' <span class="warn">(geen bron gekozen: er is geen audio)</span>'} → ${outs.length ? outs.join(", ") : '<span class="empty">nergens naartoe (geen bus aan)</span>'}`;
  }).filter(Boolean);
  $("surf-explain").innerHTML = (sim.pressed ? `<div class="pressed">${sim.pressed.text}</div>` : '<div class="pressed empty">Klik op een knop of schuif een fader.</div>')
    + `<div class="active-list"><b>Actief nu:</b> ${lines.length ? lines.join("<br>") : '<span class="empty">geen module open (fader omlaag of module uit)</span>'}</div>`
    + (liveOn ? `<details class="live-log" ${liveLog.length ? "open" : ""}><summary>MambaNet-berichten (laatste ${liveLog.length})</summary>${liveLog.map((x) => x.err
      ? `<div class="issue error"><span>${esc(x.err)}</span></div>`
      : `<div><span>${new Date(x.t * 1000).toLocaleTimeString("nl-NL")}</span><span>${x.dir === "in" ? "surface → engine" : "engine → surface"}</span><code>obj ${x.f.object}</code> ${esc(x.f.description)} · ${esc(x.f.name)} · <b>${esc(x.what)}</b></div>`).join("")}</details>` : "");

  const heads = ["Bronnen", "Modules op deze surface", "Bussen", "Monitorbussen", "Bestemmingen", "Kaart-outputs"];
  const html = '<svg id="surf-svg"></svg>' + cols.map((c, i) =>
    `<div class="col"><h3>${heads[i]}</h3>${c.map((b) => `<div class="fbox ${b.cls} ${b.on ? "live" : "idle"}" id="${b.id}"><b>${b.title}</b><small>${esc(b.sub)}</small></div>`).join("") || '<span class="empty">–</span>'}</div>`).join("")
    + JSON.stringify(surfEdges);
  if (html === lastFlowHtml && $("surf-svg")?.childElementCount) return;   // niets veranderd: lijnen niet opnieuw starten
  lastFlowHtml = html;
  $("surf-flow").innerHTML = html.slice(0, html.length - JSON.stringify(surfEdges).length);
  requestAnimationFrame(drawSurfLines);
}

function drawSurfLines() {
  const svg = $("surf-svg"); if (!svg) return;
  const base = $("surf-flow").getBoundingClientRect(); if (!base.width) return;
  svg.innerHTML = surfEdges.map(([a, b, on]) => {
    const ea = $(a), eb = $(b); if (!ea || !eb) return "";
    const ra = ea.getBoundingClientRect(), rb = eb.getBoundingClientRect();
    const x1 = ra.right - base.left, y1 = ra.top + ra.height / 2 - base.top;
    const x2 = rb.left - base.left, y2 = rb.top + rb.height / 2 - base.top, dx = (x2 - x1) / 2;
    return `<path class="${on ? "live" : "idle"}" d="M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}"/>`;
  }).join("");
}
window.addEventListener("resize", () => requestAnimationFrame(drawSurfLines));

let reloadTimer = null;
function connectEvents() {
  const es = new EventSource("/api/events");
  es.addEventListener("hello", () => $("live").className = "dot on");
  es.addEventListener("change", (e) => {
    const items = JSON.parse(e.data);
    if (S && items.length) { S.changes = [...items.reverse(), ...S.changes].slice(0, 50); renderLog(items.length); }
    clearTimeout(reloadTimer);
    reloadTimer = setTimeout(load, 400);   // bundel snelle reeksen wijzigingen
  });
  es.onerror = () => ($("live").className = "dot off");
}

load();
if (!location.search.includes("nolive")) connectEvents();   // ?nolive = zonder live-updates (voor tests)
const startTab = new URLSearchParams(location.search).get("tab");
if (startTab) document.querySelector(`#tabs button[data-view="${startTab}"]`)?.click();
