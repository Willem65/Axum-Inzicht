"""Systeem-informatie (vervanging van http://<engine>/system), alleen lezen.

Database: MambaNet-nodes, templates, voorgedefinieerde configuraties, functies, register.
Engine-bestanden (logs, pakketversies) worden opgehaald via de oude webpagina,
omdat die op de engine zelf draait en die bestanden kan lezen.
"""
import base64
import html
import os
import re
import urllib.request

import psycopg2.extras
from fastapi import APIRouter, HTTPException

router = APIRouter(prefix="/api/system")

WEB_URL = os.environ.get("AXUM_WEB_URL", "http://192.168.1.222")
WEB_AUTH = os.environ.get("AXUM_WEB_AUTH", "service:service")

MB_TYPES = {0: "geen data", 1: "unsigned int", 2: "signed int", 3: "state", 4: "octet string",
            5: "float", 6: "bit string"}
LOGS = {"engine": "axum-engine.log", "gateway": "axum-gateway.log", "address": "axum-address.log",
        "learner": "axum-learner.log", "postgresql": "postgresql.log"}

_connect = None  # wordt gezet door app.py


def init(connect):
    global _connect
    _connect = connect


def query(sql, *args):
    conn = _connect()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(sql, args)
        return [dict(r) for r in cur.fetchall()]
    finally:
        conn.close()


def fetch_web(path):
    req = urllib.request.Request(WEB_URL + path)
    req.add_header("Authorization", "Basic " + base64.b64encode(WEB_AUTH.encode()).decode())
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read().decode("utf-8", "replace")
    except Exception as e:
        raise HTTPException(502, f"Oude webpagina niet bereikbaar: {e}")


def content_of(page):
    m = re.search(r'<div id="content">(.*)</div></body>', page, re.S)
    return m.group(1) if m else page


@router.get("/mambanet")
def mambanet():
    return query("""
        SELECT a.addr, a.name, (a.id).man AS man, (a.id).prod AS prod, (a.id).id AS uid,
               (a.parent).man AS p_man, (a.parent).prod AS p_prod, (a.parent).id AS p_id,
               (SELECT b.name FROM addresses b WHERE (b.id).man = (a.parent).man AND (b.id).prod = (a.parent).prod
                    AND (b.id).id = (a.parent).id) AS parent_name,
               a.engine_addr, a.services, a.active, a.firm_major, a.addr_requests, a.user_level_from_console,
               a.firstseen::text, a.lastseen::text, s.slot_nr,
               (SELECT COUNT(*) FROM templates t WHERE t.man_id = (a.id).man AND t.prod_id = (a.id).prod
                    AND t.firm_major = a.firm_major) AS objects,
               (SELECT COUNT(*) FROM node_config n WHERE n.addr = a.addr AND n.firm_major = a.firm_major) AS config_cnt,
               (SELECT COUNT(*) FROM defaults d WHERE d.addr = a.addr AND d.firm_major = a.firm_major) AS default_cnt
        FROM addresses a LEFT JOIN slot_config s ON s.addr = a.addr ORDER BY a.addr""")


@router.get("/templates")
def templates():
    return query("""
        SELECT t.man_id, t.prod_id, t.firm_major, COUNT(*) AS count,
               (SELECT a.name FROM addresses a WHERE (a.id).man = t.man_id AND (a.id).prod = t.prod_id
                    AND a.firm_major = t.firm_major ORDER BY a.active DESC LIMIT 1) AS node_name,
               (SELECT COUNT(*) FROM addresses a WHERE (a.id).man = t.man_id AND (a.id).prod = t.prod_id
                    AND a.firm_major = t.firm_major) AS nodes
        FROM templates t GROUP BY t.man_id, t.prod_id, t.firm_major ORDER BY t.man_id, t.prod_id, t.firm_major""")


@router.get("/templates/{man}/{prod}/{fw}")
def template_detail(man: int, prod: int, fw: int):
    rows = query("""
        SELECT number, description, services, sensor_type, sensor_size,
               (sensor_min).int AS smin_i, (sensor_min).fl AS smin_f, (sensor_max).int AS smax_i, (sensor_max).fl AS smax_f,
               actuator_type, actuator_size,
               (actuator_min).int AS amin_i, (actuator_min).fl AS amin_f,
               (actuator_max).int AS amax_i, (actuator_max).fl AS amax_f,
               (actuator_def).int AS adef_i, (actuator_def).fl AS adef_f
        FROM templates WHERE man_id = %s AND prod_id = %s AND firm_major = %s ORDER BY number""", man, prod, fw)
    for r in rows:
        r["sensor"] = MB_TYPES.get(r["sensor_type"], r["sensor_type"])
        r["actuator"] = MB_TYPES.get(r["actuator_type"], r["actuator_type"])
        use_f = lambda t: t == 5
        r["sensor_range"] = rng(r["smin_f"] if use_f(r["sensor_type"]) else r["smin_i"],
                                r["smax_f"] if use_f(r["sensor_type"]) else r["smax_i"]) if r["sensor_type"] else ""
        r["actuator_range"] = rng(r["amin_f"] if use_f(r["actuator_type"]) else r["amin_i"],
                                  r["amax_f"] if use_f(r["actuator_type"]) else r["amax_i"]) if r["actuator_type"] else ""
        r["actuator_default"] = (r["adef_f"] if use_f(r["actuator_type"]) else r["adef_i"]) if r["actuator_type"] else None
    return rows


def rng(a, b):
    return "" if a is None and b is None else f"{a} … {b}"


@router.get("/predefined")
def predefined():
    return query("""
        SELECT man_id, prod_id, firm_major, cfg_name, SUM(cfg) AS config, SUM(dflt) AS defaults FROM (
            SELECT man_id, prod_id, firm_major, cfg_name, 1 AS cfg, 0 AS dflt FROM predefined_node_config
            UNION ALL
            SELECT man_id, prod_id, firm_major, cfg_name, 0, 1 FROM predefined_node_defaults) x
        GROUP BY man_id, prod_id, firm_major, cfg_name ORDER BY man_id, prod_id, firm_major, cfg_name""")


@router.get("/functions")
def functions():
    rows = query("""
        SELECT (func).type AS type, (func).func AS func, name, rcv_type, xmt_type, pos, label,
               user_level0, user_level1, user_level2, user_level3, user_level4, user_level5
        FROM functions ORDER BY (func).type, pos""")
    for r in rows:
        r["rcv"] = MB_TYPES.get(r["rcv_type"], r["rcv_type"])
        r["xmt"] = MB_TYPES.get(r["xmt_type"], r["xmt_type"])
    return rows


@router.get("/versions")
def versions():
    page = content_of(fetch_web("/system/versions?pkg=Axum"))
    out = []
    for tr in re.findall(r"<tr>(.*?)</tr>", page, re.S):
        cells = [html.unescape(re.sub(r"<[^>]+>", "", c)).strip() for c in re.findall(r"<td>(.*?)</td>", tr, re.S)]
        if len(cells) == 4:
            out.append(dict(name=cells[0], version=cells[1], build=cells[2], installed=cells[3]))
    return out


@router.get("/logs/{name}")
def logs(name: str, lines: int = 400):
    if name not in LOGS:  # alleen vaste namen: de oude pagina zet dit ongefilterd in een shell-commando
        raise HTTPException(404, "Onbekend logbestand")
    page = content_of(fetch_web(f"/system/logs?filename={LOGS[name]}"))
    text = html.unescape(re.sub(r"<br\s*/?>", "\n", page))
    text = re.sub(r"<[^>]+>", "", text)
    all_lines = text.splitlines()
    return dict(file=LOGS[name], total=len(all_lines), lines=all_lines[-max(1, min(lines, 5000)):])
